Imports System.Collections.Generic
Imports GSM.Plugin

Namespace GSM.NodeApi

    ' ============================================================
    '  Node identity and status
    ' ============================================================

    Public Class NodeStatusResponse
        Public Property NodeId As String
        Public Property MachineName As String
        Public Property OsDescription As String
        Public Property UptimeSeconds As Long
        Public Property CpuPercent As Double
        Public Property MemoryUsedMb As Long
        Public Property MemoryTotalMb As Long
        Public Property DiskFreeGb As Long
        Public Property RunningInstanceCount As Integer
    End Class

    ' ============================================================
    '  Instance management
    ' ============================================================

    Public Class StartInstanceRequest
        Public Property InstanceId As String
        Public Property ExePath As String
        Public Property Arguments As String
        Public Property WorkingDirectory As String
        Public Property EnvironmentVars As Dictionary(Of String, String)
        Public Property CrashPolicy As CrashRestartPolicy
    End Class

    Public Class StopInstanceRequest
        Public Property InstanceId As String
        Public Property GracefulTimeoutMs As Integer = 10000
    End Class

    Public Class InstanceStatusResponse
        Public Property InstanceId As String
        Public Property CurrentState As InstanceState
        Public Property ProcessId As Integer
        Public Property UptimeSeconds As Long
        Public Property CpuPercent As Double
        Public Property MemoryMb As Long
        Public Property PlayerCount As Integer
        Public Property PlayerNames As List(Of String)
    End Class

    ' ============================================================
    '  Install / Update
    ' ============================================================

    Public Class InstallRequest
        Public Property JobId As String
        Public Property InstallationId As String
        Public Property InstallPath As String
        Public Property Steps As List(Of InstallStep)
    End Class

    Public Class InstallProgressResponse
        Public Property JobId As String
        Public Property IsComplete As Boolean
        Public Property IsSuccess As Boolean
        Public Property ProgressPercent As Integer
        Public Property CurrentStage As String
        Public Property ErrorMessage As String
        Public Property RequiresInput As Boolean
        Public Property InputPrompt As String
    End Class

    Public Class InstallInputRequest
        Public Property JobId As String
        Public Property InputText As String
    End Class

    ' ============================================================
    '  RCON
    ' ============================================================

    Public Class RconConnectRequest
        Public Property InstanceId As String
        Public Property Protocol As RconProtocol
        Public Property Port As Integer
        Public Property Password As String
        Public Property TimeoutMs As Integer = 5000
    End Class

    Public Class RconCommandRequest
        Public Property InstanceId As String
        Public Property Command As String
    End Class

    Public Class RconResponse
        Public Property Succeeded As Boolean
        Public Property ResponseText As String
        Public Property ErrorMessage As String
    End Class

    Public Class RconStatusResponse
        Public Property InstanceId As String
        Public Property IsConnected As Boolean
        Public Property Protocol As RconProtocol
    End Class

    ' ============================================================
    '  Log streaming (callback-based, not IAsyncEnumerable)
    ' ============================================================

    Public Class LogStreamRequest
        Public Property InstanceId As String
        Public Property TailLines As Integer = 100
        Public Property Follow As Boolean = True
    End Class

    ' ============================================================
    '  Authentication
    ' ============================================================

    Public Class NodeAuthRequest
        Public Property SharedSecret As String
        Public Property ManagerId As String
    End Class

    Public Class NodeAuthResponse
        Public Property Accepted As Boolean
        Public Property SessionToken As String
        Public Property Reason As String
    End Class

    ' ============================================================
    '  Steam credentials (transient, never persisted on node)
    ' ============================================================

    Public Class SteamCredential
        Public Property Username As String
        Public Property Password As String
        Public Property IsAnonymous As Boolean
    End Class

End Namespace
