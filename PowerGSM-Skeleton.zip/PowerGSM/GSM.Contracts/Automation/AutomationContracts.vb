Imports System.Collections.Generic
Imports System.Threading
Imports System.Threading.Tasks
Imports GSM.Plugin

Namespace GSM.Automation

    ' ============================================================
    '  Enums
    ' ============================================================

    Public Enum RuleScope
        InstanceScope
        InstallationScope
        AllInstances
    End Enum

    Public Enum TriggerKind
        Schedule
        StateChange
        VersionMismatch
        Manual
    End Enum

    ' ============================================================
    '  Rule definition (persisted as JSON)
    ' ============================================================

    Public Class RuleDefinition
        Public Property RuleId As String
        Public Property RuleName As String
        Public Property IsEnabled As Boolean = True
        Public Property ScopeKind As RuleScope
        Public Property TargetId As String
        Public Property TriggerJson As String
        Public Property ConditionsJson As String
        Public Property ActionJson As String
    End Class

    ' ============================================================
    '  Trigger / Condition / Action interfaces
    ' ============================================================

    Public Interface ITrigger
        ReadOnly Property TriggerId As String
        ReadOnly Property DisplayLabel As String
        ReadOnly Property Kind As TriggerKind
    End Interface

    Public Interface ICondition
        ReadOnly Property ConditionId As String
        ReadOnly Property DisplayLabel As String
        Function Evaluate(ctx As RuleContext,
                          cancellation As CancellationToken) As Task(Of ConditionResult)
    End Interface

    Public Interface IAction
        ReadOnly Property ActionId As String
        ReadOnly Property DisplayLabel As String
        Function Execute(ctx As RuleContext,
                         cancellation As CancellationToken) As Task(Of ActionResult)
    End Interface

    ' ============================================================
    '  Result types
    ' ============================================================

    Public Class ConditionResult
        Public Property Passed As Boolean
        Public Property Reason As String

        Public Shared Function Pass(Optional reason As String = "") As ConditionResult
            Return New ConditionResult With {.Passed = True, .Reason = reason}
        End Function

        Public Shared Function Fail(reason As String) As ConditionResult
            Return New ConditionResult With {.Passed = False, .Reason = reason}
        End Function
    End Class

    Public Class ActionResult
        Public Property Succeeded As Boolean
        Public Property Message As String
        Public Property Data As Dictionary(Of String, Object)

        Public Shared Function Ok(Optional message As String = "") As ActionResult
            Return New ActionResult With {.Succeeded = True, .Message = message}
        End Function

        Public Shared Function Fail(message As String) As ActionResult
            Return New ActionResult With {.Succeeded = False, .Message = message}
        End Function
    End Class

    ' ============================================================
    '  State info (returned by RuleContext)
    ' ============================================================

    Public Class InstanceStateInfo
        Public Property InstanceId As String
        Public Property CurrentState As InstanceState
        Public Property StateEnteredAt As DateTime
        Public Property PlayerCount As Integer
        Public Property PlayerNames As List(Of String)
    End Class

    ' ============================================================
    '  RuleContext - abstract base, implemented in GSM.Manager
    '  Actions and conditions interact with the system ONLY
    '  through this context. Never import manager namespaces.
    ' ============================================================

    Public MustInherit Class RuleContext

        ' ---- Instance operations ----

        Public MustOverride Function GetInstanceStateInfo(
            cancellation As CancellationToken) As Task(Of InstanceStateInfo)

        Public MustOverride Function StartInstance(
            cancellation As CancellationToken) As Task(Of ActionResult)

        Public MustOverride Function StopInstance(
            graceful As Boolean,
            cancellation As CancellationToken) As Task(Of ActionResult)

        Public MustOverride Function RestartInstance(
            graceful As Boolean,
            cancellation As CancellationToken) As Task(Of ActionResult)

        Public MustOverride Function SendRconCommand(
            command As String,
            cancellation As CancellationToken) As Task(Of ActionResult)

        Public MustOverride Function ResumeCrashRetries(
            cancellation As CancellationToken) As Task(Of ActionResult)

        ' ---- Installation operations ----

        Public MustOverride Function StopAllInstancesForInstallation(
            graceful As Boolean,
            cancellation As CancellationToken) As Task(Of ActionResult)

        Public MustOverride Function StartAllInstancesForInstallation(
            cancellation As CancellationToken) As Task(Of ActionResult)

        Public MustOverride Function UpdateInstallation(
            cancellation As CancellationToken) As Task(Of ActionResult)

        Public MustOverride Function IsInstallationLocked(
            cancellation As CancellationToken) As Task(Of Boolean)

        ' ---- Notification ----

        Public MustOverride Function SendNotification(
            pluginId As String,
            context As NotificationContext,
            cancellation As CancellationToken) As Task(Of NotificationResult)

        ' ---- Logging ----

        Public MustOverride Sub LogProgress(message As String)

    End Class

End Namespace
