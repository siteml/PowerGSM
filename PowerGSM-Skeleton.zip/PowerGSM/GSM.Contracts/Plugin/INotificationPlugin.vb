Imports System.Collections.Generic
Imports System.Threading
Imports System.Threading.Tasks
Imports GSM.Automation

Namespace GSM.Plugin

    ' ============================================================
    '  Notification severity
    ' ============================================================

    Public Enum NotificationSeverity
        Info
        Warning
        ErrorLevel
        Critical
    End Enum

    ' ============================================================
    '  INotificationPlugin
    ' ============================================================

    Public Interface INotificationPlugin

        ReadOnly Property PluginId As String
        ReadOnly Property DisplayName As String

        ' ---- Lifecycle ----

        Function InitialiseAsync(config As NotificationPluginConfig,
                                 handler As IRemoteCommandHandler,
                                 cancellation As CancellationToken) As Task

        Function ShutdownAsync(cancellation As CancellationToken) As Task

        ' ---- Outbound ----

        Function SendNotificationAsync(context As NotificationContext,
                                       cancellation As CancellationToken) As Task(Of NotificationResult)

        ' ---- Inbound ----

        Function GetSupportedCommands() As IReadOnlyList(Of RemoteCommandDescriptor)

        ' ---- Config ----

        Function GetConfigSchema() As IReadOnlyList(Of ConfigFieldDescriptor)

    End Interface

    ' ============================================================
    '  Remote command handler (manager implements, plugin calls)
    ' ============================================================

    Public Interface IRemoteCommandHandler
        Function HandleAsync(command As InboundCommand,
                             cancellation As CancellationToken) As Task(Of CommandResult)
    End Interface

    ' ============================================================
    '  Notification types
    ' ============================================================

    Public Class NotificationPluginConfig
        Public Property PluginId As String
        Public Property RawJson As String
        Public Property IsEnabled As Boolean
    End Class

    Public Class NotificationContext
        Public Property RuleId As String
        Public Property RuleName As String
        Public Property Severity As NotificationSeverity
        Public Property ResolvedMessage As String
        Public Property MessageTemplate As String
        Public Property Tokens As NotificationTokens
        Public Property ScopeKind As RuleScope
        Public Property TargetInstanceId As String
        Public Property TargetInstallationId As String
        Public Property ExecutionLog As List(Of String)
        Public Property RoutingHints As Dictionary(Of String, String)
    End Class

    Public Class NotificationTokens
        Public Property InstanceName As String
        Public Property InstallationName As String
        Public Property NodeName As String
        Public Property GameId As String
        Public Property PlayerCount As Integer
        Public Property PlayerNames As List(Of String)
        Public Property ExitCode As Integer
        Public Property ErrorMessage As String
        Public Property InstalledVersion As String
        Public Property LatestVersion As String
        Public Property Custom As Dictionary(Of String, String)
    End Class

    Public Class NotificationResult
        Public Property Succeeded As Boolean
        Public Property FailureReason As String

        Public Shared Function Ok() As NotificationResult
            Return New NotificationResult With {.Succeeded = True}
        End Function

        Public Shared Function Fail(reason As String) As NotificationResult
            Return New NotificationResult With {.Succeeded = False, .FailureReason = reason}
        End Function
    End Class

    Public Class NotificationSubscription
        Public Property SubscriptionId As String
        Public Property PluginId As String
        Public Property EventName As String
        Public Property ScopeKind As RuleScope
        Public Property TargetId As String
        Public Property RoutingHints As Dictionary(Of String, String)
    End Class

    ' ============================================================
    '  Remote command types
    ' ============================================================

    Public Class RemoteCommandDescriptor
        Public Property CommandName As String
        Public Property Description As String
        Public Property Parameters As List(Of CommandParameterDescriptor)
        Public Property RequiresInstanceTarget As Boolean
    End Class

    Public Class CommandParameterDescriptor
        Public Property Name As String
        Public Property Description As String
        Public Property IsRequired As Boolean
        Public Property DefaultValue As String
    End Class

    Public Class InboundCommand
        Public Property CommandName As String
        Public Property Parameters As Dictionary(Of String, String)
        Public Property TargetInstanceId As String
        Public Property SourcePluginId As String
        Public Property PlatformContext As Object
    End Class

    Public Class CommandResult
        Public Property Succeeded As Boolean
        Public Property ResponseText As String
        Public Property Data As Dictionary(Of String, Object)

        Public Shared Function Ok(response As String) As CommandResult
            Return New CommandResult With {.Succeeded = True, .ResponseText = response}
        End Function

        Public Shared Function Fail(reason As String) As CommandResult
            Return New CommandResult With {.Succeeded = False, .ResponseText = reason}
        End Function
    End Class

End Namespace
