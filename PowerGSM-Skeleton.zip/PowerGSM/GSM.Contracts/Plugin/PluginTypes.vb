Imports System.Collections.Generic

Namespace GSM.Plugin

    ' ============================================================
    '  Enums
    ' ============================================================

    Public Enum InstallMethod
        SteamCmd
        DirectDownload
    End Enum

    Public Enum ConfigFieldType
        Text
        Password
        NumberField
        BooleanField
        Choice
        CredentialPicker
        FilePath
    End Enum

    Public Enum RconProtocol
        SourceRcon
        FactorioRcon
    End Enum

    Public Enum InstanceState
        Stopped
        Starting
        Running
        Stopping
        Crashed
        Restarting
        StartFailed
        CrashLoopHalted
        InstallationLocked
        Updating
        Installing
    End Enum

    Public Enum CrashLoopBehaviour
        NotifyOnly
        NotifyAndWait
    End Enum

    Public Enum RestartDecision
        WillRestart
        HaltedCrashLoop
        HaltedCleanExit
        HaltedAutoRestartOff
        HaltedInstallLocked
    End Enum

    ' ============================================================
    '  Install types
    ' ============================================================

    Public Class InstallStep
        Public Property StepId As String
        Public Property DisplayLabel As String
        Public Property Command As String
        Public Property Arguments As String
        Public Property WorkingDirectory As String
        Public Property UseStdin As Boolean
        Public Property TimeoutSeconds As Integer = 600
    End Class

    Public Class ValidationResult
        Public Property IsValid As Boolean
        Public Property Reason As String

        Public Shared Function Success() As ValidationResult
            Return New ValidationResult With {.IsValid = True, .Reason = String.Empty}
        End Function

        Public Shared Function Failure(reason As String) As ValidationResult
            Return New ValidationResult With {.IsValid = False, .Reason = reason}
        End Function
    End Class

    ' ============================================================
    '  Config types
    ' ============================================================

    Public Class ConfigFieldDescriptor
        Public Property Key As String
        Public Property Label As String
        Public Property Description As String
        Public Property FieldType As ConfigFieldType = ConfigFieldType.Text
        Public Property DefaultValue As String = String.Empty
        Public Property IsRequired As Boolean = False
        Public Property IsSensitive As Boolean = False
        Public Property Choices As List(Of String)
    End Class

    Public Class InstallationConfig
        Public Property InstallationId As String
        Public Property GameId As String
        Public Property InstallPath As String
        Public Property NodeId As String
        Public Property RawJson As String
    End Class

    Public Class InstanceConfig
        Public Property InstanceId As String
        Public Property DisplayName As String
        Public Property InstallationId As String
        Public Property GameId As String
        Public Property RawJson As String
        Public Property ExeOverride As String
    End Class

    ' ============================================================
    '  RCON types
    ' ============================================================

    Public Class RconInfo
        Public Property Protocol As RconProtocol
        Public Property Port As Integer
        Public Property Password As String
        Public Property ConnectTimeoutMs As Integer = 5000
        Public Property MaxPacketSize As Integer = 4096
        Public Property AutoConnect As Boolean = True
        Public Property StartupDelayMs As Integer = 3000
        Public Property MaxConnectRetries As Integer = 5
        Public Property RetryIntervalMs As Integer = 2000
    End Class

    ' ============================================================
    '  Crash handling types
    ' ============================================================

    Public Class CrashRestartPolicy
        Public Property AutoRestart As Boolean = True
        Public Property MaxRestartsInWindow As Integer = 3
        Public Property WindowMinutes As Integer = 15
        Public Property BackoffBaseSeconds As Integer = 5
        Public Property BackoffMultiplier As Double = 2.0
        Public Property BackoffMaxSeconds As Integer = 300
        Public Property CrashLoopAction As CrashLoopBehaviour = CrashLoopBehaviour.NotifyOnly
        Public Property StopIntentTimeoutMs As Integer = 30000
    End Class

    Public Class CrashEvent
        Public Property CrashEventId As String
        Public Property InstanceId As String
        Public Property OccurredAt As DateTime
        Public Property ExitCode As Integer
        Public Property StopIntentWasSet As Boolean
        Public Property CrashState As InstanceState
        Public Property RestartAction As RestartDecision
        Public Property RestartDecisionReason As String
        Public Property AttemptNumber As Integer
        Public Property BackoffAppliedSeconds As Integer
        Public Property LogContextLines As List(Of String)
    End Class

    ' ============================================================
    '  Logging types
    ' ============================================================

    Public Class LogLine
        Public Property Timestamp As DateTime
        Public Property SourceId As String
        Public Property Text As String
        Public Property IsError As Boolean
    End Class

    ' ============================================================
    '  Log source types
    ' ============================================================

    Public Interface ILogSource
        ReadOnly Property SourceId As String
    End Interface

    Public Class StdoutLogSource
        Implements ILogSource

        Public ReadOnly Property SourceId As String = "stdout" Implements ILogSource.SourceId
        Public Property CaptureStderr As Boolean = True
    End Class

    Public Class FileLogSource
        Implements ILogSource

        Private ReadOnly _sourceId As String
        Private ReadOnly _pathPattern As String

        Public Sub New(sourceId As String, pathPattern As String)
            _sourceId = sourceId
            _pathPattern = pathPattern
        End Sub

        Public ReadOnly Property SourceId As String Implements ILogSource.SourceId
            Get
                Return _sourceId
            End Get
        End Property

        Public ReadOnly Property PathPattern As String
            Get
                Return _pathPattern
            End Get
        End Property

        Public Property FollowRotation As Boolean = False
    End Class

End Namespace
