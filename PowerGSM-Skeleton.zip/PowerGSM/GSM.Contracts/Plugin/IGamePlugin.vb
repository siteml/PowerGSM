Imports System.Collections.Generic
Imports System.Threading
Imports System.Threading.Tasks

Namespace GSM.Plugin

    ''' <summary>
    ''' Core contract for game server plugins. Each supported game
    ''' implements this interface. The manager compiles and loads
    ''' plugins via Roslyn and resolves all game-specific logic
    ''' through this contract. Nodes receive plain data only.
    ''' </summary>
    Public Interface IGamePlugin

        ' ---- Identity ----

        ReadOnly Property GameId As String
        ReadOnly Property DisplayName As String

        ' ---- Install ----

        Function GetSupportedInstallMethods() As IReadOnlyList(Of InstallMethod)

        Function GetInstallSteps(installPath As String,
                                 method As InstallMethod,
                                 config As InstallationConfig) As IReadOnlyList(Of InstallStep)

        Function ValidateInstall(installPath As String) As ValidationResult

        Function GetSteamBranch(config As InstallationConfig) As String

        ' ---- Launch ----

        Function GetExecutablePath(installPath As String,
                                   instance As InstanceConfig) As String

        Function BuildCommandLine(instance As InstanceConfig) As String

        Function GetWorkingDirectory(installPath As String,
                                     instance As InstanceConfig) As String

        ' ---- Logging ----

        Function GetLogSources(installPath As String,
                               instance As InstanceConfig) As IReadOnlyList(Of ILogSource)

        Function GetLogParser() As ILogParser

        ' ---- Install monitoring ----

        Function GetInstallMonitor() As IInstallMonitor

        ' ---- RCON ----

        Function GetRconInfo(instance As InstanceConfig) As RconInfo

        ' ---- Mods ----

        Function GetModManager() As IModManager

        ' ---- Crash handling ----

        Function GetCleanExitCodes() As IReadOnlyList(Of Integer)
        Function GetCrashSignalPatterns() As IReadOnlyList(Of String)

        ' ---- Version detection ----

        Function GetInstalledVersion(installPath As String) As String

        Function GetLatestVersion(config As InstallationConfig,
                                  cancellation As CancellationToken) As Task(Of String)

        ' ---- Config schema ----

        Function GetInstanceConfigSchema() As IReadOnlyList(Of ConfigFieldDescriptor)
        Function GetInstallationConfigSchema() As IReadOnlyList(Of ConfigFieldDescriptor)

    End Interface

    ' ============================================================
    '  Supporting interfaces
    ' ============================================================

    Public Interface ILogParser
        Sub ProcessLine(line As String)
        ReadOnly Property ActivePlayers As IReadOnlyList(Of String)
    End Interface

    Public Interface IInstallMonitor
        Sub ProcessLine(line As String)
        ReadOnly Property ProgressPercent As Integer
        ReadOnly Property CurrentStage As String
        ReadOnly Property RequiresUserInput As Boolean
        ReadOnly Property UserInputPrompt As String
    End Interface

    Public Interface IModManager
        Function GetInstalledMods(installPath As String) As IReadOnlyList(Of String)
        Function InstallMod(installPath As String, modId As String,
                            cancellation As CancellationToken) As Task(Of Boolean)
        Function RemoveMod(installPath As String, modId As String) As Boolean
    End Interface

    ''' <summary>
    ''' Detects orphaned installations/instances when a plugin is
    ''' removed during hot-reload. The manager calls this to
    ''' determine what to do with data that referenced the now-
    ''' missing plugin.
    ''' </summary>
    Public Interface IOrphanDetector
        Function GetOrphanedInstallationIds(gameId As String) As IReadOnlyList(Of String)
        Function GetOrphanedInstanceIds(gameId As String) As IReadOnlyList(Of String)
    End Interface

End Namespace
