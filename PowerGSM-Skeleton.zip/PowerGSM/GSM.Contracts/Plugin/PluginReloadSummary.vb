Imports System.Collections.Generic

Namespace GSM.Plugin

    ''' <summary>
    ''' Summarises the result of a plugin hot-reload cycle.
    ''' The manager uses this to detect added, removed, and
    ''' updated plugins and to flag orphaned installations.
    ''' </summary>
    Public Class PluginReloadSummary
        Public Property LoadedPlugins As List(Of String)
        Public Property AddedGameIds As List(Of String)
        Public Property RemovedGameIds As List(Of String)
        Public Property UpdatedGameIds As List(Of String)
        Public Property CompilationErrors As List(Of PluginCompilationError)
        Public Property OrphanedInstallationIds As List(Of String)
        Public Property OrphanedInstanceIds As List(Of String)
    End Class

    Public Class PluginCompilationError
        Public Property FileName As String
        Public Property Line As Integer
        Public Property Column As Integer
        Public Property ErrorCode As String
        Public Property Message As String
    End Class

End Namespace
