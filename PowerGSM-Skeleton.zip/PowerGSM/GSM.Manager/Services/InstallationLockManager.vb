Imports System.Collections.Concurrent
Imports System.Threading
Imports System.Threading.Tasks

Namespace GSM.Manager.Services

    ''' <summary>
    ''' Reader/writer lock per installation. Running instances are
    ''' readers (many can coexist). An update is a writer (exclusive
    ''' access, waits for all readers to finish, blocks new readers).
    ''' 
    ''' This prevents updating install files while instances are
    ''' using them, and prevents starting instances mid-update.
    ''' </summary>
    Public Class InstallationLockManager

        Private ReadOnly _locks As New ConcurrentDictionary(Of String, InstallationLock)

        ''' <summary>
        ''' Acquire a read lock (instance starting). Returns a disposable
        ''' that releases the lock. Returns Nothing if a write lock is held.
        ''' </summary>
        Public Function TryAcquireReadLock(installationId As String) As IDisposable
            Dim installLock = _locks.GetOrAdd(installationId,
                Function(id) New InstallationLock())
            If installLock.TryEnterRead() Then
                Return New ReadLockHandle(installLock)
            End If
            Return Nothing
        End Function

        ''' <summary>
        ''' Acquire a write lock (update starting). Blocks until all
        ''' readers release. Respects cancellation.
        ''' </summary>
        Public Async Function AcquireWriteLockAsync(
                installationId As String,
                cancellation As CancellationToken) As Task(Of IDisposable)
            Dim installLock = _locks.GetOrAdd(installationId,
                Function(id) New InstallationLock())
            Await installLock.EnterWriteAsync(cancellation)
            Return New WriteLockHandle(installLock)
        End Function

        ''' <summary>
        ''' Check if a write lock is currently held (for condition checks).
        ''' </summary>
        Public Function IsWriteLocked(installationId As String) As Boolean
            Dim installLock As InstallationLock = Nothing
            If _locks.TryGetValue(installationId, installLock) Then
                Return installLock.IsWriteLocked
            End If
            Return False
        End Function

    End Class

    ' ============================================================
    '  Internal lock implementation
    ' ============================================================

    Friend Class InstallationLock

        Private ReadOnly _rwLock As New ReaderWriterLockSlim()
        Private ReadOnly _writeSemaphore As New SemaphoreSlim(1, 1)

        Public ReadOnly Property IsWriteLocked As Boolean
            Get
                Return _rwLock.IsWriteLockHeld
            End Get
        End Property

        Public Function TryEnterRead() As Boolean
            Return _rwLock.TryEnterReadLock(0)
        End Function

        Public Sub ExitRead()
            _rwLock.ExitReadLock()
        End Sub

        Public Async Function EnterWriteAsync(cancellation As CancellationToken) As Task
            Await _writeSemaphore.WaitAsync(cancellation)
            ' TODO: Wait for all readers to exit before proceeding.
            '       For now, use a simple spin-wait with delay.
            While _rwLock.CurrentReadCount > 0
                cancellation.ThrowIfCancellationRequested()
                Await Task.Delay(250, cancellation)
            End While
            _rwLock.EnterWriteLock()
        End Function

        Public Sub ExitWrite()
            _rwLock.ExitWriteLock()
            _writeSemaphore.Release()
        End Sub

    End Class

    Friend Class ReadLockHandle
        Implements IDisposable

        Private ReadOnly _lock As InstallationLock

        Public Sub New(installLock As InstallationLock)
            _lock = installLock
        End Sub

        Public Sub Dispose() Implements IDisposable.Dispose
            _lock.ExitRead()
        End Sub
    End Class

    Friend Class WriteLockHandle
        Implements IDisposable

        Private ReadOnly _lock As InstallationLock

        Public Sub New(installLock As InstallationLock)
            _lock = installLock
        End Sub

        Public Sub Dispose() Implements IDisposable.Dispose
            _lock.ExitWrite()
        End Sub
    End Class

End Namespace
