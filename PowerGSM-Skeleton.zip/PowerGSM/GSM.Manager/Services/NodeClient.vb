Imports System.Net.Http
Imports System.Net.Http.Json
Imports System.Threading
Imports System.Threading.Tasks
Imports GSM.NodeApi
Imports GSM.Plugin

Namespace GSM.Manager.Services

    ''' <summary>
    ''' Communicates with GSM.Node REST API instances over HTTP.
    ''' Each node is addressed by host:port with a shared secret
    ''' for authentication.
    ''' 
    ''' Log streaming uses SSE (Server-Sent Events) consumed via
    ''' StreamReader — not WebSockets. The callback Action(Of LogLine)
    ''' is invoked for each received line.
    ''' </summary>
    Public Class NodeClient

        Private ReadOnly _httpClient As New HttpClient()

        ' ---- Node status ----

        Public Async Function GetNodeStatusAsync(
                hostAddress As String, port As Integer,
                cancellation As CancellationToken) As Task(Of NodeStatusResponse)
            Dim url = $"http://{hostAddress}:{port}/status"
            Return Await _httpClient.GetFromJsonAsync(Of NodeStatusResponse)(url, cancellation)
        End Function

        ' ---- Instance lifecycle ----

        Public Async Function StartInstanceAsync(
                hostAddress As String, port As Integer,
                request As StartInstanceRequest,
                cancellation As CancellationToken) As Task(Of InstanceStatusResponse)
            Dim url = $"http://{hostAddress}:{port}/instance/start"
            Dim response = Await _httpClient.PostAsJsonAsync(url, request, cancellation)
            response.EnsureSuccessStatusCode()
            Return Await response.Content.ReadFromJsonAsync(Of InstanceStatusResponse)(cancellationToken:=cancellation)
        End Function

        Public Async Function StopInstanceAsync(
                hostAddress As String, port As Integer,
                request As StopInstanceRequest,
                cancellation As CancellationToken) As Task(Of InstanceStatusResponse)
            Dim url = $"http://{hostAddress}:{port}/instance/stop"
            Dim response = Await _httpClient.PostAsJsonAsync(url, request, cancellation)
            response.EnsureSuccessStatusCode()
            Return Await response.Content.ReadFromJsonAsync(Of InstanceStatusResponse)(cancellationToken:=cancellation)
        End Function

        Public Async Function GetInstanceStatusAsync(
                hostAddress As String, port As Integer,
                instanceId As String,
                cancellation As CancellationToken) As Task(Of InstanceStatusResponse)
            Dim url = $"http://{hostAddress}:{port}/instance/{instanceId}/status"
            Return Await _httpClient.GetFromJsonAsync(Of InstanceStatusResponse)(url, cancellation)
        End Function

        ' ---- Install ----

        Public Async Function StartInstallAsync(
                hostAddress As String, port As Integer,
                request As InstallRequest,
                cancellation As CancellationToken) As Task(Of InstallProgressResponse)
            Dim url = $"http://{hostAddress}:{port}/install"
            Dim response = Await _httpClient.PostAsJsonAsync(url, request, cancellation)
            response.EnsureSuccessStatusCode()
            Return Await response.Content.ReadFromJsonAsync(Of InstallProgressResponse)(cancellationToken:=cancellation)
        End Function

        Public Async Function GetInstallProgressAsync(
                hostAddress As String, port As Integer,
                jobId As String,
                cancellation As CancellationToken) As Task(Of InstallProgressResponse)
            Dim url = $"http://{hostAddress}:{port}/install/{jobId}/progress"
            Return Await _httpClient.GetFromJsonAsync(Of InstallProgressResponse)(url, cancellation)
        End Function

        ' ---- RCON ----

        Public Async Function SendRconCommandAsync(
                hostAddress As String, port As Integer,
                request As RconCommandRequest,
                cancellation As CancellationToken) As Task(Of RconResponse)
            Dim url = $"http://{hostAddress}:{port}/rcon/send"
            Dim response = Await _httpClient.PostAsJsonAsync(url, request, cancellation)
            response.EnsureSuccessStatusCode()
            Return Await response.Content.ReadFromJsonAsync(Of RconResponse)(cancellationToken:=cancellation)
        End Function

        ' ---- Log streaming (SSE via callback) ----

        ''' <summary>
        ''' Connect to a node's log SSE stream and invoke the callback
        ''' for each received LogLine. Runs until cancelled.
        ''' </summary>
        Public Async Function StreamLogsAsync(
                hostAddress As String, port As Integer,
                instanceId As String,
                onLine As Action(Of LogLine),
                cancellation As CancellationToken) As Task

            Dim url = $"http://{hostAddress}:{port}/instance/{instanceId}/logs"
            Using response = Await _httpClient.GetAsync(url,
                    HttpCompletionOption.ResponseHeadersRead, cancellation)
                response.EnsureSuccessStatusCode()
                Using stream = Await response.Content.ReadAsStreamAsync(cancellation)
                    Using reader As New IO.StreamReader(stream)
                        While Not cancellation.IsCancellationRequested
                            Dim line = Await reader.ReadLineAsync(cancellation)
                            If line Is Nothing Then Exit While
                            If line.StartsWith("data: ") Then
                                ' TODO: Deserialize JSON after "data: " prefix
                                Dim logLine As New LogLine With {
                                    .Timestamp = DateTime.UtcNow,
                                    .Text = line.Substring(6),
                                    .SourceId = "sse"
                                }
                                onLine(logLine)
                            End If
                        End While
                    End Using
                End Using
            End Using
        End Function

    End Class

End Namespace
