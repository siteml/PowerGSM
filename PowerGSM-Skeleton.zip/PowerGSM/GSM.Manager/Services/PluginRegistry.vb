Imports System.Collections.Generic
Imports System.IO
Imports System.Reflection
Imports System.Runtime.Loader
Imports GSM.Plugin

Namespace GSM.Manager.Services

    ''' <summary>
    ''' Compiles .vb plugin source files using Roslyn and loads
    ''' them into isolated AssemblyLoadContexts. Supports manual
    ''' hot-reload: unload old context, compile fresh, load new.
    ''' 
    ''' Instances never hold a direct plugin reference. They store
    ''' a GameId and resolve through GetPlugin(gameId) at the
    ''' moment they need it.
    ''' </summary>
    Public Class PluginRegistry

        Private ReadOnly _gamePlugins As New Dictionary(Of String, IGamePlugin)
        Private ReadOnly _notificationPlugins As New Dictionary(Of String, INotificationPlugin)
        Private ReadOnly _lock As New Object()
        Private _loadContext As AssemblyLoadContext

        Private ReadOnly _pluginFolder As String =
            Path.Combine(AppContext.BaseDirectory, "plugins")

        ' ---- Query ----

        Public Function GetPlugin(gameId As String) As IGamePlugin
            SyncLock _lock
                Dim plugin As IGamePlugin = Nothing
                _gamePlugins.TryGetValue(gameId, plugin)
                Return plugin
            End SyncLock
        End Function

        Public Function GetAllGamePlugins() As IReadOnlyList(Of IGamePlugin)
            SyncLock _lock
                Return New List(Of IGamePlugin)(_gamePlugins.Values)
            End SyncLock
        End Function

        Public Function GetNotificationPlugin(pluginId As String) As INotificationPlugin
            SyncLock _lock
                Dim plugin As INotificationPlugin = Nothing
                _notificationPlugins.TryGetValue(pluginId, plugin)
                Return plugin
            End SyncLock
        End Function

        Public Function GetAllNotificationPlugins() As IReadOnlyList(Of INotificationPlugin)
            SyncLock _lock
                Return New List(Of INotificationPlugin)(_notificationPlugins.Values)
            End SyncLock
        End Function

        ' ---- Load / Reload ----

        ''' <summary>
        ''' Scan the plugins folder, compile all .vb files, and register
        ''' any types implementing IGamePlugin or INotificationPlugin.
        ''' Returns a summary of what was loaded, added, removed, or failed.
        ''' </summary>
        Public Function LoadAll() As PluginReloadSummary
            ' TODO: Phase 3/4 implementation
            '  1. Enumerate *.vb files in _pluginFolder
            '  2. Compile each with Microsoft.CodeAnalysis.VisualBasic
            '  3. Load resulting assembly into new AssemblyLoadContext
            '  4. Scan for IGamePlugin / INotificationPlugin implementations
            '  5. Register in dictionaries
            '  6. Build summary with adds/removes/errors

            Return New PluginReloadSummary With {
                .LoadedPlugins = New List(Of String),
                .AddedGameIds = New List(Of String),
                .RemovedGameIds = New List(Of String),
                .UpdatedGameIds = New List(Of String),
                .CompilationErrors = New List(Of PluginCompilationError),
                .OrphanedInstallationIds = New List(Of String),
                .OrphanedInstanceIds = New List(Of String)
            }
        End Function

        ''' <summary>
        ''' Unload current plugins and reload from disk.
        ''' Manual-only — never called automatically.
        ''' Running instances continue with their last-resolved
        ''' command lines; only new operations use the new plugins.
        ''' </summary>
        Public Function Reload() As PluginReloadSummary
            SyncLock _lock
                Dim previousGameIds = New HashSet(Of String)(_gamePlugins.Keys)

                ' Unload old context
                If _loadContext IsNot Nothing Then
                    _loadContext.Unload()
                    _loadContext = Nothing
                End If

                _gamePlugins.Clear()
                _notificationPlugins.Clear()

                ' Load fresh
                Dim summary = LoadAll()

                ' Detect removed plugins
                For Each oldId In previousGameIds
                    If Not _gamePlugins.ContainsKey(oldId) Then
                        summary.RemovedGameIds.Add(oldId)
                    End If
                Next

                Return summary
            End SyncLock
        End Function

    End Class

End Namespace
