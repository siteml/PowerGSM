Imports System.Collections.Generic
Imports System.Threading
Imports System.Threading.Tasks
Imports GSM.Automation
Imports GSM.Plugin

Namespace GSM.Manager.Services

    ''' <summary>
    ''' Evaluates automation rules. Listens for triggers (schedules,
    ''' state changes, version mismatches), checks conditions, and
    ''' executes actions through a RuleContext.
    ''' 
    ''' Rules are persisted as JSON in the database and re-hydrated
    ''' at startup. The engine runs on a background thread and
    ''' processes rules sequentially per scope to avoid conflicts.
    ''' </summary>
    Public Class AutomationEngine

        Private ReadOnly _pluginRegistry As PluginRegistry
        Private ReadOnly _nodeClient As NodeClient
        Private ReadOnly _lockManager As InstallationLockManager
        Private ReadOnly _rules As New List(Of RuleDefinition)
        Private ReadOnly _rulesLock As New Object()
        Private _engineCts As CancellationTokenSource

        Public Sub New(pluginRegistry As PluginRegistry,
                       nodeClient As NodeClient,
                       lockManager As InstallationLockManager)
            _pluginRegistry = pluginRegistry
            _nodeClient = nodeClient
            _lockManager = lockManager
        End Sub

        ' ---- Lifecycle ----

        ''' <summary>
        ''' Load rules from the database and start the evaluation loop.
        ''' </summary>
        Public Sub Start()
            ' TODO: Load rules from GsmDbContext
            ' TODO: Start background task for schedule-based triggers
            _engineCts = New CancellationTokenSource()
        End Sub

        ''' <summary>
        ''' Stop the evaluation loop. In-progress rules run to completion
        ''' (respecting their own CancellationTokens).
        ''' </summary>
        Public Sub Shutdown()
            If _engineCts IsNot Nothing Then
                _engineCts.Cancel()
            End If
        End Sub

        ' ---- Rule management ----

        Public Sub AddRule(rule As RuleDefinition)
            SyncLock _rulesLock
                _rules.Add(rule)
            End SyncLock
            ' TODO: Persist to database
        End Sub

        Public Sub RemoveRule(ruleId As String)
            SyncLock _rulesLock
                _rules.RemoveAll(Function(r) r.RuleId = ruleId)
            End SyncLock
            ' TODO: Remove from database
        End Sub

        Public Sub SetRuleEnabled(ruleId As String, enabled As Boolean)
            SyncLock _rulesLock
                Dim rule = _rules.Find(Function(r) r.RuleId = ruleId)
                If rule IsNot Nothing Then
                    rule.IsEnabled = enabled
                End If
            End SyncLock
            ' TODO: Update database
        End Sub

        Public Function GetAllRules() As IReadOnlyList(Of RuleDefinition)
            SyncLock _rulesLock
                Return New List(Of RuleDefinition)(_rules)
            End SyncLock
        End Function

        ' ---- Trigger entry points ----

        ''' <summary>
        ''' Called by the state-change monitor when an instance transitions.
        ''' Finds matching StateChange-triggered rules and evaluates them.
        ''' </summary>
        Public Async Function OnInstanceStateChanged(
                instanceId As String,
                oldState As InstanceState,
                newState As InstanceState,
                cancellation As CancellationToken) As Task
            ' TODO: Find rules with StateChange trigger matching this transition
            ' TODO: Evaluate conditions, execute actions via RuleContext
            Await Task.CompletedTask
        End Function

        ''' <summary>
        ''' Called by the version poller when a mismatch is detected.
        ''' </summary>
        Public Async Function OnVersionMismatch(
                installationId As String,
                installedVersion As String,
                latestVersion As String,
                cancellation As CancellationToken) As Task
            ' TODO: Find rules with VersionMismatch trigger for this installation
            Await Task.CompletedTask
        End Function

        ''' <summary>
        ''' Manually fire a rule by ID (e.g. from UI button or remote command).
        ''' </summary>
        Public Async Function FireRuleManually(
                ruleId As String,
                cancellation As CancellationToken) As Task(Of ActionResult)
            ' TODO: Locate rule, skip trigger check, evaluate conditions, execute
            Return ActionResult.Fail("Not yet implemented")
        End Function

    End Class

End Namespace
