Imports System.Windows.Forms
Imports Microsoft.EntityFrameworkCore
Imports GSM.Manager.Data
Imports GSM.Manager.Services
Imports GSM.Manager.UI
Imports GSM.Plugin

Module Program

    <STAThread>
    Sub Main()

        ' Ensure database exists and is migrated
        Using db As New GsmDbContext()
            db.Database.EnsureCreated()
        End Using

        ' Initialise core services
        Dim pluginRegistry As New PluginRegistry()
        Dim lockManager As New InstallationLockManager()
        Dim nodeClient As New NodeClient()
        Dim automationEngine As New AutomationEngine(pluginRegistry, nodeClient, lockManager)

        ' Load plugins on startup
        Dim summary = pluginRegistry.LoadAll()
        If summary.CompilationErrors.Count > 0 Then
            For Each compErr In summary.CompilationErrors
                Console.Error.WriteLine($"Plugin error in {compErr.FileName}: {compErr.Message}")
            Next
        End If

        ' Launch UI
        Application.SetHighDpiMode(HighDpiMode.SystemAware)
        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)

        Dim mainForm As New MainForm(pluginRegistry, nodeClient, automationEngine, lockManager)
        Application.Run(mainForm)

    End Sub

End Module
