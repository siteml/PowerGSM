Imports System.Windows.Forms
Imports GSM.Manager.Services

Namespace GSM.Manager.UI

    Public Class MainForm
        Inherits Form

        Private ReadOnly _pluginRegistry As PluginRegistry
        Private ReadOnly _nodeClient As NodeClient
        Private ReadOnly _automationEngine As AutomationEngine
        Private ReadOnly _lockManager As InstallationLockManager

        ' ---- UI Controls (will be built out in Phase 4) ----
        Private WithEvents _statusStrip As StatusStrip
        Private _statusLabel As ToolStripStatusLabel
        Private _mainSplitContainer As SplitContainer
        Private _treeView As TreeView
        Private _tabControl As TabControl

        Public Sub New(pluginRegistry As PluginRegistry,
                       nodeClient As NodeClient,
                       automationEngine As AutomationEngine,
                       lockManager As InstallationLockManager)

            _pluginRegistry = pluginRegistry
            _nodeClient = nodeClient
            _automationEngine = automationEngine
            _lockManager = lockManager

            InitializeComponent()
        End Sub

        Private Sub InitializeComponent()
            Me.Text = "PowerGSM - Game Server Manager"
            Me.Size = New Drawing.Size(1200, 800)
            Me.StartPosition = FormStartPosition.CenterScreen

            ' Status bar
            _statusStrip = New StatusStrip()
            _statusLabel = New ToolStripStatusLabel("Ready")
            _statusStrip.Items.Add(_statusLabel)
            Me.Controls.Add(_statusStrip)

            ' Main split: tree on left, tabs on right
            _mainSplitContainer = New SplitContainer With {
                .Dock = DockStyle.Fill,
                .SplitterDistance = 250,
                .FixedPanel = FixedPanel.Panel1
            }

            ' Tree view for nodes/installations/instances
            _treeView = New TreeView With {
                .Dock = DockStyle.Fill
            }
            _mainSplitContainer.Panel1.Controls.Add(_treeView)

            ' Tab control for details panels
            _tabControl = New TabControl With {
                .Dock = DockStyle.Fill
            }
            _tabControl.TabPages.Add("Overview", "Overview")
            _tabControl.TabPages.Add("Console", "Console")
            _tabControl.TabPages.Add("Config", "Configuration")
            _tabControl.TabPages.Add("Automation", "Automation")
            _mainSplitContainer.Panel2.Controls.Add(_tabControl)

            Me.Controls.Add(_mainSplitContainer)

            ' Bring split container in front of status strip
            _mainSplitContainer.BringToFront()
        End Sub

        Protected Overrides Sub OnLoad(e As EventArgs)
            MyBase.OnLoad(e)
            _statusLabel.Text = $"Loaded {_pluginRegistry.GetAllGamePlugins().Count} game plugin(s)"
            ' TODO: Populate tree with nodes/installations/instances from DB
        End Sub

        Protected Overrides Sub OnFormClosing(e As FormClosingEventArgs)
            _automationEngine.Shutdown()
            MyBase.OnFormClosing(e)
        End Sub

    End Class

End Namespace
