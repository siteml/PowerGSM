Imports Microsoft.EntityFrameworkCore

Namespace GSM.Manager.Data

    Public Class GsmDbContext
        Inherits DbContext

        Public Property Nodes As DbSet(Of NodeEntity)
        Public Property Installations As DbSet(Of InstallationEntity)
        Public Property Instances As DbSet(Of InstanceEntity)
        Public Property AutomationRules As DbSet(Of AutomationRuleEntity)
        Public Property SteamCredentials As DbSet(Of SteamCredentialEntity)
        Public Property RealmCredentials As DbSet(Of RealmCredentialEntity)
        Public Property NotificationSubscriptions As DbSet(Of NotificationSubscriptionEntity)

        Protected Overrides Sub OnConfiguring(optionsBuilder As DbContextOptionsBuilder)
            If Not optionsBuilder.IsConfigured Then
                optionsBuilder.UseSqlite("Data Source=gsm.db")
            End If
        End Sub

        Protected Overrides Sub OnModelCreating(modelBuilder As ModelBuilder)

            modelBuilder.Entity(Of NodeEntity)(
                Sub(e)
                    e.HasKey(Function(n) n.NodeId)
                    e.Property(Function(n) n.DisplayName).IsRequired()
                    e.Property(Function(n) n.HostAddress).IsRequired()
                End Sub)

            modelBuilder.Entity(Of InstallationEntity)(
                Sub(e)
                    e.HasKey(Function(i) i.InstallationId)
                    e.Property(Function(i) i.GameId).IsRequired()
                    e.Property(Function(i) i.InstallPath).IsRequired()
                    e.HasOne(Function(i) i.Node).
                        WithMany(Function(n) n.Installations).
                        HasForeignKey(Function(i) i.NodeId)
                End Sub)

            modelBuilder.Entity(Of InstanceEntity)(
                Sub(e)
                    e.HasKey(Function(i) i.InstanceId)
                    e.Property(Function(i) i.GameId).IsRequired()
                    e.HasOne(Function(i) i.Installation).
                        WithMany(Function(inst) inst.Instances).
                        HasForeignKey(Function(i) i.InstallationId)
                End Sub)

            modelBuilder.Entity(Of AutomationRuleEntity)(
                Sub(e)
                    e.HasKey(Function(r) r.RuleId)
                    e.Property(Function(r) r.RuleName).IsRequired()
                End Sub)

            modelBuilder.Entity(Of SteamCredentialEntity)(
                Sub(e)
                    e.HasKey(Function(c) c.CredentialId)
                    e.Property(Function(c) c.Username).IsRequired()
                End Sub)

            modelBuilder.Entity(Of RealmCredentialEntity)(
                Sub(e)
                    e.HasKey(Function(c) c.CredentialId)
                    e.Property(Function(c) c.GameId).IsRequired()
                End Sub)

            modelBuilder.Entity(Of NotificationSubscriptionEntity)(
                Sub(e)
                    e.HasKey(Function(s) s.SubscriptionId)
                    e.Property(Function(s) s.PluginId).IsRequired()
                End Sub)

        End Sub

    End Class

End Namespace
