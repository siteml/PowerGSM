Namespace GSM.Manager.Data

    ''' <summary>
    ''' A managed machine running the GSM.Node service.
    ''' </summary>
    Public Class NodeEntity
        Public Property NodeId As String
        Public Property DisplayName As String
        Public Property HostAddress As String
        Public Property Port As Integer = 8765
        Public Property SharedSecret As String
        Public Property IsEnabled As Boolean = True
        Public Property LastSeenUtc As DateTime
        Public Property OsDescription As String

        Public Overridable Property Installations As ICollection(Of InstallationEntity)
    End Class

    ''' <summary>
    ''' A set of game server files on a specific node.
    ''' One installation can serve multiple instances (e.g. Last Oasis).
    ''' </summary>
    Public Class InstallationEntity
        Public Property InstallationId As String
        Public Property GameId As String
        Public Property DisplayName As String
        Public Property NodeId As String
        Public Property InstallPath As String
        Public Property InstallMethod As String
        Public Property InstalledVersion As String
        Public Property ConfigJson As String
        Public Property CreatedUtc As DateTime
        Public Property UpdatedUtc As DateTime

        Public Overridable Property Node As NodeEntity
        Public Overridable Property Instances As ICollection(Of InstanceEntity)
    End Class

    ''' <summary>
    ''' A running (or configured) game server instance.
    ''' Belongs to exactly one installation.
    ''' </summary>
    Public Class InstanceEntity
        Public Property InstanceId As String
        Public Property InstallationId As String
        Public Property DisplayName As String
        Public Property GameId As String
        Public Property ConfigJson As String
        Public Property ExeOverride As String
        Public Property AutoStart As Boolean = False
        Public Property CreatedUtc As DateTime
        Public Property UpdatedUtc As DateTime

        Public Overridable Property Installation As InstallationEntity
    End Class

    ''' <summary>
    ''' A persisted automation rule.
    ''' </summary>
    Public Class AutomationRuleEntity
        Public Property RuleId As String
        Public Property RuleName As String
        Public Property IsEnabled As Boolean = True
        Public Property ScopeKind As String
        Public Property TargetId As String
        Public Property TriggerJson As String
        Public Property ConditionsJson As String
        Public Property ActionJson As String
        Public Property CreatedUtc As DateTime
        Public Property UpdatedUtc As DateTime
    End Class

    ''' <summary>
    ''' Steam credentials encrypted with DPAPI.
    ''' Password is stored as a byte array — only decryptable
    ''' on the same Windows account that encrypted it.
    ''' </summary>
    Public Class SteamCredentialEntity
        Public Property CredentialId As String
        Public Property DisplayName As String
        Public Property Username As String
        Public Property EncryptedPassword As Byte()
        Public Property IsAnonymous As Boolean
    End Class

    ''' <summary>
    ''' Realm credentials for games that require them (e.g. Last Oasis).
    ''' Keys are DPAPI-encrypted.
    ''' </summary>
    Public Class RealmCredentialEntity
        Public Property CredentialId As String
        Public Property DisplayName As String
        Public Property GameId As String
        Public Property EncryptedCustomerKey As Byte()
        Public Property EncryptedProviderKey As Byte()
    End Class

    ''' <summary>
    ''' A notification subscription (always-on event watching).
    ''' </summary>
    Public Class NotificationSubscriptionEntity
        Public Property SubscriptionId As String
        Public Property PluginId As String
        Public Property EventName As String
        Public Property ScopeKind As String
        Public Property TargetId As String
        Public Property RoutingHintsJson As String
        Public Property IsEnabled As Boolean = True
    End Class

End Namespace
