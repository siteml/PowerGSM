Imports Microsoft.AspNetCore.Builder
Imports Microsoft.AspNetCore.Http
Imports Microsoft.Extensions.DependencyInjection
Imports GSM.Node.Services
Imports GSM.NodeApi

Module Program

    Sub Main(args As String())

        Dim builder = WebApplication.CreateBuilder(args)

        ' ---- Register services ----
        builder.Services.AddSingleton(Of ProcessManager)()
        builder.Services.AddSingleton(Of LogBuffer)()
        builder.Services.AddSingleton(Of RconManager)()

        Dim app = builder.Build()

        ' ============================================================
        '  Endpoints
        ' ============================================================

        ' ---- Node status ----
        app.MapGet("/status", Function(pm As ProcessManager)
                                  Return Results.Ok(pm.GetNodeStatus())
                              End Function)

        ' ---- Instance lifecycle ----
        app.MapPost("/instance/start", Async Function(req As StartInstanceRequest,
                                                       pm As ProcessManager)
                                           Dim result = Await pm.StartInstanceAsync(req)
                                           Return Results.Ok(result)
                                       End Function)

        app.MapPost("/instance/stop", Async Function(req As StopInstanceRequest,
                                                      pm As ProcessManager)
                                          Dim result = Await pm.StopInstanceAsync(req)
                                          Return Results.Ok(result)
                                      End Function)

        app.MapGet("/instance/{instanceId}/status", Function(instanceId As String,
                                                              pm As ProcessManager)
                                                        Dim result = pm.GetInstanceStatus(instanceId)
                                                        If result Is Nothing Then
                                                            Return Results.NotFound()
                                                        End If
                                                        Return Results.Ok(result)
                                                    End Function)

        ' ---- Install / Update ----
        app.MapPost("/install", Async Function(req As InstallRequest,
                                                pm As ProcessManager)
                                    Dim result = Await pm.StartInstallAsync(req)
                                    Return Results.Ok(result)
                                End Function)

        app.MapGet("/install/{jobId}/progress", Function(jobId As String,
                                                          pm As ProcessManager)
                                                    Dim result = pm.GetInstallProgress(jobId)
                                                    If result Is Nothing Then
                                                        Return Results.NotFound()
                                                    End If
                                                    Return Results.Ok(result)
                                                End Function)

        app.MapPost("/install/{jobId}/input", Async Function(jobId As String,
                                                              req As InstallInputRequest,
                                                              pm As ProcessManager)
                                                  Await pm.ProvideInstallInputAsync(jobId, req.InputText)
                                                  Return Results.Ok()
                                              End Function)

        ' ---- RCON ----
        app.MapPost("/rcon/connect", Async Function(req As RconConnectRequest,
                                                     rm As RconManager)
                                         Dim result = Await rm.ConnectAsync(req)
                                         Return Results.Ok(result)
                                     End Function)

        app.MapPost("/rcon/send", Async Function(req As RconCommandRequest,
                                                  rm As RconManager)
                                      Dim result = Await rm.SendCommandAsync(req)
                                      Return Results.Ok(result)
                                  End Function)

        app.MapGet("/rcon/{instanceId}/status", Function(instanceId As String,
                                                          rm As RconManager)
                                                    Return Results.Ok(rm.GetStatus(instanceId))
                                                End Function)

        app.MapPost("/rcon/{instanceId}/disconnect", Async Function(instanceId As String,
                                                                     rm As RconManager)
                                                         Await rm.DisconnectAsync(instanceId)
                                                         Return Results.Ok()
                                                     End Function)

        ' ---- Logs (callback via SSE) ----
        app.MapGet("/instance/{instanceId}/logs", Async Function(instanceId As String,
                                                                  context As HttpContext,
                                                                  lb As LogBuffer)
                                                      context.Response.ContentType = "text/event-stream"
                                                      Await lb.StreamLogsAsync(
                                                          instanceId,
                                                          context.Response,
                                                          context.RequestAborted)
                                                      Return Results.Empty
                                                  End Function)

        app.Run()

    End Sub

End Module
