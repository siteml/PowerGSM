Imports System.Collections.Concurrent
Imports System.Threading
Imports System.Threading.Tasks
Imports Microsoft.AspNetCore.Http
Imports GSM.Plugin

Namespace GSM.Node.Services

    ''' <summary>
    ''' Ring buffer that stores log lines per instance and can
    ''' stream them to the manager via Server-Sent Events (SSE).
    ''' Uses callback-based streaming (not IAsyncEnumerable).
    ''' </summary>
    Public Class LogBuffer

        Private ReadOnly _buffers As New ConcurrentDictionary(Of String, InstanceLogBuffer)

        ''' <summary>
        ''' Append a log line for the given instance.
        ''' Called by ProcessManager when stdout/stderr data arrives.
        ''' </summary>
        Public Sub Append(instanceId As String, line As LogLine)
            Dim buf = _buffers.GetOrAdd(instanceId, Function(id) New InstanceLogBuffer(id))
            buf.Add(line)
        End Sub

        ''' <summary>
        ''' Stream log lines as SSE events to the HTTP response.
        ''' Sends tail lines first, then follows new lines until cancelled.
        ''' </summary>
        Public Async Function StreamLogsAsync(instanceId As String,
                                              response As HttpResponse,
                                              cancellation As CancellationToken) As Task
            ' TODO: Send tail lines, then enter follow loop using
            '       a SemaphoreSlim or channel to signal new lines.
            '       Write each line as "data: {json}\n\n" SSE format.
            Await Task.Delay(Timeout.Infinite, cancellation).ConfigureAwait(False)
        End Function

        ''' <summary>
        ''' Get recent lines without streaming (for one-shot requests).
        ''' </summary>
        Public Function GetRecentLines(instanceId As String,
                                       count As Integer) As IReadOnlyList(Of LogLine)
            Dim buf As InstanceLogBuffer = Nothing
            If Not _buffers.TryGetValue(instanceId, buf) Then
                Return Array.Empty(Of LogLine)()
            End If
            Return buf.GetTail(count)
        End Function

    End Class

    Friend Class InstanceLogBuffer

        Private ReadOnly _instanceId As String
        Private ReadOnly _ring(4095) As LogLine   ' 4096 line ring buffer
        Private _writePos As Long = 0
        Private ReadOnly _lock As New Object()

        Public Sub New(instanceId As String)
            _instanceId = instanceId
        End Sub

        Public Sub Add(line As LogLine)
            SyncLock _lock
                _ring(CInt(_writePos Mod _ring.Length)) = line
                _writePos += 1
            End SyncLock
        End Sub

        Public Function GetTail(count As Integer) As IReadOnlyList(Of LogLine)
            SyncLock _lock
                Dim available = CInt(Math.Min(_writePos, _ring.Length))
                Dim take = Math.Min(count, available)
                Dim result As New List(Of LogLine)(take)
                For i = _writePos - take To _writePos - 1
                    Dim idx = CInt(i Mod _ring.Length)
                    If _ring(idx) IsNot Nothing Then
                        result.Add(_ring(idx))
                    End If
                Next
                Return result
            End SyncLock
        End Function

    End Class

End Namespace
