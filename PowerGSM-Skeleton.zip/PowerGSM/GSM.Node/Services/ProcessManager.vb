Imports System.Collections.Concurrent
Imports System.Threading
Imports System.Threading.Tasks
Imports GSM.NodeApi
Imports GSM.Plugin

Namespace GSM.Node.Services

    ''' <summary>
    ''' Manages game server processes on this node.
    ''' Handles start/stop/restart, crash detection, stdout capture,
    ''' and install job execution.
    ''' </summary>
    Public Class ProcessManager

        Private ReadOnly _instances As New ConcurrentDictionary(Of String, ManagedInstance)
        Private ReadOnly _installJobs As New ConcurrentDictionary(Of String, InstallJob)

        ' ---- Node status ----

        Public Function GetNodeStatus() As NodeStatusResponse
            Return New NodeStatusResponse With {
                .NodeId = Environment.MachineName,
                .MachineName = Environment.MachineName,
                .OsDescription = System.Runtime.InteropServices.RuntimeInformation.OSDescription,
                .RunningInstanceCount = _instances.Count
            }
            ' TODO: populate CPU, memory, disk metrics
        End Function

        ' ---- Instance lifecycle ----

        Public Function StartInstanceAsync(req As StartInstanceRequest) As Task(Of InstanceStatusResponse)
            ' TODO: Launch process, capture stdout, apply crash policy
            Throw New NotImplementedException("ProcessManager.StartInstanceAsync")
        End Function

        Public Function StopInstanceAsync(req As StopInstanceRequest) As Task(Of InstanceStatusResponse)
            ' TODO: Set stop intent flag, send graceful stop, wait, force-kill
            Throw New NotImplementedException("ProcessManager.StopInstanceAsync")
        End Function

        Public Function GetInstanceStatus(instanceId As String) As InstanceStatusResponse
            ' TODO: Return current state from _instances dictionary
            Dim inst As ManagedInstance = Nothing
            If Not _instances.TryGetValue(instanceId, inst) Then
                Return Nothing
            End If
            Return New InstanceStatusResponse With {
                .InstanceId = instanceId,
                .CurrentState = inst.State
            }
        End Function

        ' ---- Install jobs ----

        Public Function StartInstallAsync(req As InstallRequest) As Task(Of InstallProgressResponse)
            ' TODO: Execute install steps sequentially, capture output
            Throw New NotImplementedException("ProcessManager.StartInstallAsync")
        End Function

        Public Function GetInstallProgress(jobId As String) As InstallProgressResponse
            Dim job As InstallJob = Nothing
            If Not _installJobs.TryGetValue(jobId, job) Then
                Return Nothing
            End If
            Return New InstallProgressResponse With {
                .JobId = jobId,
                .IsComplete = job.IsComplete,
                .IsSuccess = job.IsSuccess,
                .ProgressPercent = job.ProgressPercent,
                .CurrentStage = job.CurrentStage
            }
        End Function

        Public Function ProvideInstallInputAsync(jobId As String, inputText As String) As Task
            ' TODO: Write to SteamCMD stdin pipe
            Throw New NotImplementedException("ProcessManager.ProvideInstallInputAsync")
        End Function

    End Class

    ' ============================================================
    '  Internal tracking classes (not exposed via API)
    ' ============================================================

    Friend Class ManagedInstance
        Public Property InstanceId As String
        Public Property State As InstanceState
        Public Property ProcessId As Integer
        Public Property StartedAt As DateTime
        Public Property CrashPolicy As CrashRestartPolicy
        Public Property StopIntentPending As Boolean
    End Class

    Friend Class InstallJob
        Public Property JobId As String
        Public Property InstallationId As String
        Public Property IsComplete As Boolean
        Public Property IsSuccess As Boolean
        Public Property ProgressPercent As Integer
        Public Property CurrentStage As String
        Public Property ErrorMessage As String
    End Class

End Namespace
