Imports System.Collections.Concurrent
Imports System.Threading.Tasks
Imports GSM.NodeApi
Imports GSM.Plugin

Namespace GSM.Node.Services

    ''' <summary>
    ''' Manages persistent RCON connections for running instances.
    ''' Supports Source RCON and Factorio RCON protocols.
    ''' Connections are held open per instance to avoid session overhead.
    ''' </summary>
    Public Class RconManager

        Private ReadOnly _connections As New ConcurrentDictionary(Of String, RconConnection)

        Public Function ConnectAsync(req As RconConnectRequest) As Task(Of RconResponse)
            ' TODO: Open TCP connection, authenticate with protocol-specific handshake
            Throw New NotImplementedException("RconManager.ConnectAsync")
        End Function

        Public Function SendCommandAsync(req As RconCommandRequest) As Task(Of RconResponse)
            ' TODO: Send command on existing connection, return response
            Throw New NotImplementedException("RconManager.SendCommandAsync")
        End Function

        Public Function GetStatus(instanceId As String) As RconStatusResponse
            Dim conn As RconConnection = Nothing
            Dim isConnected = _connections.TryGetValue(instanceId, conn) AndAlso
                              conn.IsConnected

            Return New RconStatusResponse With {
                .InstanceId = instanceId,
                .IsConnected = isConnected,
                .Protocol = If(conn IsNot Nothing, conn.Protocol, RconProtocol.SourceRcon)
            }
        End Function

        Public Function DisconnectAsync(instanceId As String) As Task
            Dim conn As RconConnection = Nothing
            If _connections.TryRemove(instanceId, conn) Then
                conn.Dispose()
            End If
            Return Task.CompletedTask
        End Function

    End Class

    Friend Class RconConnection
        Implements IDisposable

        Public Property InstanceId As String
        Public Property Protocol As RconProtocol
        Public Property IsConnected As Boolean

        Public Sub Dispose() Implements IDisposable.Dispose
            IsConnected = False
            ' TODO: Close TCP socket
        End Sub

    End Class

End Namespace
