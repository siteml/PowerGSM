Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Threading
Imports System.Threading.Tasks
Imports GSM.Plugin

' ============================================================
'  Factorio Headless Server Plugin
'
'  AppID: 427520 (free dedicated server via SteamCMD)
'  Also available as direct download from factorio.com
'  RCON: Source RCON protocol (Factorio implements it natively)
'  Mods: Factorio Mod Portal API
'
'  Install config:
'    SteamBranch     — beta branch (blank = stable)
'
'  Instance config:
'    Port            — UDP game port, default 34197
'    RconPort        — RCON port, default 27015
'    RconPassword    — RCON password (required for RCON)
'    SaveFile        — path to save file, default "save.zip"
'    ServerSettings  — path to server-settings.json
'    MapGenSettings  — path to map-gen-settings.json
'    MapSettings     — path to map-settings.json
'    UseLatestSave   — use most recent save, default true
' ============================================================

Public Class FactorioPlugin
    Implements IGamePlugin

    Public ReadOnly Property GameId As String = "factorio" Implements IGamePlugin.GameId
    Public ReadOnly Property DisplayName As String = "Factorio" Implements IGamePlugin.DisplayName

    ' ============================================================
    '  Install
    ' ============================================================

    Public Function GetSupportedInstallMethods() As IReadOnlyList(Of InstallMethod) Implements IGamePlugin.GetSupportedInstallMethods
        Return New InstallMethod() {InstallMethod.SteamCmd, InstallMethod.DirectDownload}
    End Function

    Public Function GetInstallSteps(config As InstallationConfig) As IReadOnlyList(Of InstallStep) Implements IGamePlugin.GetInstallSteps
        Dim steps As New List(Of InstallStep)

        If config.InstallMethod = InstallMethod.SteamCmd Then
            Dim steamStep As New SteamCmdStep()
            steamStep.StepName = "Download Factorio Server"
            steamStep.Description = "Download/update via SteamCMD (AppID 427520)"
            steamStep.AppId = 427520
            steamStep.ValidateFiles = True
            steamStep.RequiresLogin = False

            If config.CustomFields IsNot Nothing Then
                Dim branch = GetField(config.CustomFields, "SteamBranch")
                If Not String.IsNullOrEmpty(branch) Then
                    steamStep.BetaBranch = branch
                End If
            End If

            steps.Add(steamStep)

        ElseIf config.InstallMethod = InstallMethod.DirectDownload Then
            ' Factorio headless download from factorio.com
            ' User must provide a download URL since it requires auth
            Dim dlUrl = GetField(config.CustomFields, "DownloadUrl")
            If Not String.IsNullOrEmpty(dlUrl) Then
                Dim dlStep As New DownloadFileStep()
                dlStep.StepName = "Download Factorio Headless"
                dlStep.Description = "Download headless server archive from factorio.com"
                dlStep.Url = dlUrl
                dlStep.DestinationRelativePath = "factorio-headless.tar.xz"
                dlStep.ExtractArchive = True
                steps.Add(dlStep)
            End If
        End If

        ' Create default server-settings.json if it doesn't exist
        Dim writeSettings As New WriteFileStep()
        writeSettings.StepName = "Create default server settings"
        writeSettings.Description = "Write server-settings.json with defaults"
        writeSettings.RelativePath = "server-settings.json"
        writeSettings.OverwriteExisting = False
        writeSettings.Content = DefaultServerSettings()
        steps.Add(writeSettings)

        Return steps
    End Function

    Public Function GetUpdateSteps(config As InstallationConfig) As IReadOnlyList(Of InstallStep) Implements IGamePlugin.GetUpdateSteps
        ' Update skips the server-settings write step
        Dim steps As New List(Of InstallStep)

        If config.InstallMethod = InstallMethod.SteamCmd Then
            Dim steamStep As New SteamCmdStep()
            steamStep.StepName = "Update Factorio Server"
            steamStep.Description = "Update via SteamCMD (AppID 427520)"
            steamStep.AppId = 427520
            steamStep.ValidateFiles = True
            steamStep.RequiresLogin = False

            If config.CustomFields IsNot Nothing Then
                Dim branch = GetField(config.CustomFields, "SteamBranch")
                If Not String.IsNullOrEmpty(branch) Then
                    steamStep.BetaBranch = branch
                End If
            End If

            steps.Add(steamStep)
        End If

        Return steps
    End Function

    ' ============================================================
    '  Instance
    ' ============================================================

    Public Function BuildLaunchArguments(config As InstanceConfig) As String Implements IGamePlugin.BuildLaunchArguments
        Dim args As New List(Of String)

        ' Start server mode
        args.Add("--start-server")

        ' Save file
        Dim saveFile = GetField(config.CustomFields, "SaveFile")
        Dim useLatest = GetField(config.CustomFields, "UseLatestSave")
        If Not String.IsNullOrEmpty(useLatest) AndAlso
           useLatest.Equals("true", StringComparison.OrdinalIgnoreCase) Then
            args.Add("!!latest")
        ElseIf Not String.IsNullOrEmpty(saveFile) Then
            args.Add(saveFile)
        Else
            args.Add("save.zip")
        End If

        ' Port
        Dim port = GetFieldInt(config.CustomFields, "Port", 34197)
        args.Add($"--port {port}")

        ' RCON
        If Not String.IsNullOrEmpty(config.RconPassword) Then
            Dim rconPort = If(config.RconPort, 27015)
            args.Add($"--rcon-port {rconPort}")
            args.Add($"--rcon-password {config.RconPassword}")
        End If

        ' Server settings
        Dim settingsPath = GetField(config.CustomFields, "ServerSettings")
        If Not String.IsNullOrEmpty(settingsPath) Then
            args.Add($"--server-settings {settingsPath}")
        Else
            args.Add("--server-settings server-settings.json")
        End If

        ' Map generation settings
        Dim mapGenPath = GetField(config.CustomFields, "MapGenSettings")
        If Not String.IsNullOrEmpty(mapGenPath) Then
            args.Add($"--map-gen-settings {mapGenPath}")
        End If

        ' Map settings
        Dim mapSettingsPath = GetField(config.CustomFields, "MapSettings")
        If Not String.IsNullOrEmpty(mapSettingsPath) Then
            args.Add($"--map-settings {mapSettingsPath}")
        End If

        Return String.Join(" ", args)
    End Function

    Public Function ValidateConfig(config As InstanceConfig) As IReadOnlyList(Of String) Implements IGamePlugin.ValidateConfig
        Dim errors As New List(Of String)
        ' Factorio has sensible defaults for most things
        ' Just ensure the save file concept is addressed
        Return errors
    End Function

    ' ============================================================
    '  Config schema
    ' ============================================================

    Public Function GetInstallConfigSchema() As IReadOnlyList(Of ConfigFieldDescriptor) Implements IGamePlugin.GetInstallConfigSchema
        Return New ConfigFieldDescriptor() {
            New ConfigFieldDescriptor With {
                .Key = "SteamBranch",
                .Label = "Steam beta branch",
                .Description = "Beta branch name. Leave blank for stable.",
                .FieldType = ConfigFieldType.Text,
                .DefaultValue = ""
            },
            New ConfigFieldDescriptor With {
                .Key = "DownloadUrl",
                .Label = "Direct download URL",
                .Description = "Factorio headless download URL (only for direct download method).",
                .FieldType = ConfigFieldType.Text
            }
        }
    End Function

    Public Function GetInstanceConfigSchema() As IReadOnlyList(Of ConfigFieldDescriptor) Implements IGamePlugin.GetInstanceConfigSchema
        Return New ConfigFieldDescriptor() {
            New ConfigFieldDescriptor With {
                .Key = "Port",
                .Label = "Game Port (UDP)",
                .Description = "Default 34197. Must be unique per instance.",
                .FieldType = ConfigFieldType.IntegerField,
                .DefaultValue = "34197",
                .MinValue = 1024,
                .MaxValue = 65535
            },
            New ConfigFieldDescriptor With {
                .Key = "RconPort",
                .Label = "RCON Port",
                .FieldType = ConfigFieldType.IntegerField,
                .DefaultValue = "27015",
                .MinValue = 1024,
                .MaxValue = 65535
            },
            New ConfigFieldDescriptor With {
                .Key = "RconPassword",
                .Label = "RCON Password",
                .Description = "Required for RCON. Factorio uses Source RCON protocol.",
                .FieldType = ConfigFieldType.Password,
                .IsSensitive = True
            },
            New ConfigFieldDescriptor With {
                .Key = "SaveFile",
                .Label = "Save File",
                .Description = "Save file name or path. Default: save.zip",
                .FieldType = ConfigFieldType.Text,
                .DefaultValue = "save.zip"
            },
            New ConfigFieldDescriptor With {
                .Key = "UseLatestSave",
                .Label = "Use latest save",
                .Description = "Start with the most recent save file.",
                .FieldType = ConfigFieldType.BooleanField,
                .DefaultValue = "true"
            },
            New ConfigFieldDescriptor With {
                .Key = "ServerSettings",
                .Label = "Server settings file",
                .Description = "Path to server-settings.json. Default: server-settings.json",
                .FieldType = ConfigFieldType.FilePath,
                .DefaultValue = "server-settings.json"
            },
            New ConfigFieldDescriptor With {
                .Key = "MapGenSettings",
                .Label = "Map generation settings",
                .Description = "Path to map-gen-settings.json (optional).",
                .FieldType = ConfigFieldType.FilePath
            },
            New ConfigFieldDescriptor With {
                .Key = "MapSettings",
                .Label = "Map settings",
                .Description = "Path to map-settings.json (optional).",
                .FieldType = ConfigFieldType.FilePath
            }
        }
    End Function

    ' ============================================================
    '  Crash handling
    ' ============================================================

    Public Function EvaluateCrash(exitCode As Integer,
                                   crashCount As Integer,
                                   policy As CrashRestartPolicy) As RestartDecision Implements IGamePlugin.EvaluateCrash
        If exitCode = 0 Then
            Return RestartDecision.Halt("Clean exit (code 0)")
        End If

        Select Case policy
            Case CrashRestartPolicy.NeverRestart
                Return RestartDecision.Halt($"NeverRestart policy (exit code {exitCode})")

            Case CrashRestartPolicy.AlwaysRestart
                Return RestartDecision.Restart(2000, $"AlwaysRestart (exit code {exitCode})")

            Case CrashRestartPolicy.RestartWithBackoff
                Dim delayMs = Math.Min(CInt(Math.Pow(2, crashCount)) * 1000, 300000)
                Return RestartDecision.Restart(delayMs,
                    $"Backoff restart (attempt {crashCount + 1}, delay {delayMs}ms)")

            Case CrashRestartPolicy.RestartLimited
                If crashCount < 5 Then
                    Return RestartDecision.Restart(5000,
                        $"Limited restart (attempt {crashCount + 1}/5)")
                End If
                Return RestartDecision.Halt($"Crash limit reached ({crashCount} crashes)")

            Case Else
                Return RestartDecision.Restart(5000, $"Default restart (exit code {exitCode})")
        End Select
    End Function

    ' ============================================================
    '  Log parsing
    ' ============================================================

    Public Function CreateLogParser() As ILogParser Implements IGamePlugin.CreateLogParser
        Return New FactorioLogParser()
    End Function

    Public Function GetLogSources(config As InstanceConfig) As IReadOnlyList(Of ILogSource) Implements IGamePlugin.GetLogSources
        ' Factorio outputs to both stdout and factorio-current.log
        Return New ILogSource() {
            New StdoutLogSource(),
            New FileLogSource("factorio-log", "factorio-current.log")
        }
    End Function

    ' ============================================================
    '  RCON — Factorio implements Source RCON natively
    ' ============================================================

    Public Function GetRconProtocol() As RconProtocol? Implements IGamePlugin.GetRconProtocol
        Return RconProtocol.SourceRcon
    End Function

    ' ============================================================
    '  Mods
    ' ============================================================

    Public Function CreateModManager() As IModManager Implements IGamePlugin.CreateModManager
        Return New FactorioModManager()
    End Function

    ' ============================================================
    '  Helpers
    ' ============================================================

    Private Shared Function GetField(fields As Dictionary(Of String, String),
                                      key As String) As String
        If fields Is Nothing Then Return ""
        Dim result As String = Nothing
        If fields.TryGetValue(key, result) Then Return If(result, "")
        Return ""
    End Function

    Private Shared Function GetFieldInt(fields As Dictionary(Of String, String),
                                         key As String,
                                         defaultValue As Integer) As Integer
        Dim strVal = GetField(fields, key)
        Dim parsed As Integer
        If Integer.TryParse(strVal, parsed) Then Return parsed
        Return defaultValue
    End Function

    Private Shared Function DefaultServerSettings() As String
        Return "{
  ""name"": ""Factorio Server"",
  ""description"": ""Managed by PowerGSM"",
  ""tags"": [""game""],
  ""max_players"": 0,
  ""visibility"": {
    ""public"": false,
    ""lan"": true
  },
  ""require_user_verification"": true,
  ""max_upload_in_kilobytes_per_second"": 0,
  ""max_upload_slots"": 5,
  ""minimum_latency_in_ticks"": 0,
  ""ignore_player_limit_for_returning_players"": false,
  ""allow_commands"": ""admins-only"",
  ""autosave_interval"": 10,
  ""autosave_slots"": 5,
  ""afk_autokick_interval"": 0,
  ""auto_pause"": true,
  ""only_admins_can_pause_the_game"": true
}"
    End Function

End Class

' ============================================================
'  Factorio Log Parser
'  Detects player joins/leaves, chat, server state, and errors
' ============================================================

Public Class FactorioLogParser
    Implements ILogParser

    Public ReadOnly Property GameId As String = "factorio" Implements ILogParser.GameId

    Public Function ParseLine(line As LogLine) As ParsedLogEvent Implements ILogParser.ParseLine
        If line Is Nothing OrElse String.IsNullOrEmpty(line.Text) Then
            Return ParsedLogEvent.NoMatch
        End If

        Dim text = line.Text

        ' Player join: "Player Name joined the game"
        If text.Contains(" joined the game") Then
            Dim playerName = text.Substring(0, text.IndexOf(" joined the game", StringComparison.Ordinal)).Trim()
            ' Strip timestamp prefix if present (e.g. "2024-01-01 12:00:00 [JOIN] PlayerName")
            Dim bracketIdx = playerName.LastIndexOf("]"c)
            If bracketIdx >= 0 Then
                playerName = playerName.Substring(bracketIdx + 1).Trim()
            End If
            Return New ParsedLogEvent With {
                .EventType = LogEventType.PlayerJoin,
                .Message = $"Player joined: {playerName}",
                .PlayerInfo = New PlayerInfo With {
                    .PlayerName = playerName,
                    .JoinedAt = line.Timestamp
                }
            }
        End If

        ' Player leave: "Player Name left the game"
        If text.Contains(" left the game") Then
            Dim playerName = text.Substring(0, text.IndexOf(" left the game", StringComparison.Ordinal)).Trim()
            Dim bracketIdx = playerName.LastIndexOf("]"c)
            If bracketIdx >= 0 Then
                playerName = playerName.Substring(bracketIdx + 1).Trim()
            End If
            Return New ParsedLogEvent With {
                .EventType = LogEventType.PlayerLeave,
                .Message = $"Player left: {playerName}",
                .PlayerInfo = New PlayerInfo With {
                    .PlayerName = playerName
                }
            }
        End If

        ' Chat message: "[CHAT] Player: message"
        If text.Contains("[CHAT]") Then
            Return New ParsedLogEvent With {
                .EventType = LogEventType.ChatMessage,
                .Message = text
            }
        End If

        ' Server ready: "Hosting game at IP"
        If text.Contains("Hosting game at") Then
            Return New ParsedLogEvent With {
                .EventType = LogEventType.ServerReady,
                .Message = "Server is ready and hosting"
            }
        End If

        ' Errors
        If text.Contains("Error ") OrElse text.Contains("FATAL") Then
            Return New ParsedLogEvent With {
                .EventType = LogEventType.ErrorOccurred,
                .Message = text
            }
        End If

        Return ParsedLogEvent.NoMatch
    End Function

    Public Function GetCrashPatterns() As IReadOnlyList(Of String) Implements ILogParser.GetCrashPatterns
        Return New String() {
            "FATAL",
            "Error: MultiplayerManager",
            "Couldn't load the map",
            "Map version ",
            "Segmentation fault"
        }
    End Function

End Class

' ============================================================
'  Factorio Mod Manager
'  Manages mods via the local mod directory
' ============================================================

Public Class FactorioModManager
    Implements IModManager

    Public ReadOnly Property GameId As String = "factorio" Implements IModManager.GameId

    Public Function GetInstalledModsAsync(installPath As String,
                                           cancellation As CancellationToken) As Task(Of IReadOnlyList(Of ModInfo)) Implements IModManager.GetInstalledModsAsync
        Dim mods As New List(Of ModInfo)

        ' Factorio mods live in <installPath>/mods/
        Dim modsDir = Path.Combine(installPath, "mods")
        If Not Directory.Exists(modsDir) Then
            Return Task.FromResult(Of IReadOnlyList(Of ModInfo))(mods)
        End If

        ' Each mod is a .zip file in the mods directory
        For Each zipFile In Directory.GetFiles(modsDir, "*.zip")
            Dim fileName = Path.GetFileNameWithoutExtension(zipFile)
            ' Factorio mod zips are named "modname_version.zip"
            Dim underscoreIdx = fileName.LastIndexOf("_"c)
            Dim modName = fileName
            Dim modVersion = ""
            If underscoreIdx > 0 Then
                modName = fileName.Substring(0, underscoreIdx)
                modVersion = fileName.Substring(underscoreIdx + 1)
            End If

            mods.Add(New ModInfo With {
                .ModId = modName,
                .ModName = modName,
                .Version = modVersion,
                .IsEnabled = True
            })
        Next

        Return Task.FromResult(Of IReadOnlyList(Of ModInfo))(mods)
    End Function

    Public Function InstallModAsync(installPath As String,
                                     modId As String,
                                     cancellation As CancellationToken) As Task(Of Boolean) Implements IModManager.InstallModAsync
        ' Full implementation would download from the Factorio Mod Portal API:
        '   https://mods.factorio.com/api/mods/{modId}
        ' For now, return False — manual mod installation is supported
        ' by placing .zip files in the mods/ directory.
        Return Task.FromResult(False)
    End Function

    Public Function RemoveModAsync(installPath As String,
                                    modId As String,
                                    cancellation As CancellationToken) As Task(Of Boolean) Implements IModManager.RemoveModAsync
        Dim modsDir = Path.Combine(installPath, "mods")
        If Not Directory.Exists(modsDir) Then Return Task.FromResult(False)

        ' Find and delete matching zip files
        For Each zipFile In Directory.GetFiles(modsDir, $"{modId}_*.zip")
            Try
                File.Delete(zipFile)
                Return Task.FromResult(True)
            Catch
                Return Task.FromResult(False)
            End Try
        Next

        Return Task.FromResult(False)
    End Function

    Public Function GetModConfigSchema(modId As String) As IReadOnlyList(Of ConfigFieldDescriptor) Implements IModManager.GetModConfigSchema
        ' Factorio mod settings are game-global, not per-mod configurable
        Return Array.Empty(Of ConfigFieldDescriptor)()
    End Function

End Class
