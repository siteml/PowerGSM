Imports System
Imports System.Collections.Generic
Imports System.IO
Imports GSM.Plugin

' ============================================================
'  Last Oasis Dedicated Server Plugin
'
'  AppID: 920720 (free dedicated server)
'  Engine: Unreal Engine 4
'  Install: SteamCMD only
'  RCON: Source RCON protocol
'  Mods: None (client-side only)
'
'  Key config fields (installation-level):
'    CustomerKey  — realm-wide auth key from MyRealm dashboard
'    ProviderKey  — provider auth key (revocable per provider)
'    SteamBranch  — beta branch name (blank = default)
'
'  Key config fields (instance-level):
'    Identifier   — unique per instance on this realm
'    Port         — game port (UDP), default 5555
'    QueryPort    — Steam query port, default 27015
'    RconPort     — RCON port, default 8081
'    RconPassword — RCON password (blank = disabled)
'    Slots        — tile slot count, default 5
'    OverrideConnectionAddress — external IP override
' ============================================================

Public Class LastOasisPlugin
    Implements IGamePlugin

    Public ReadOnly Property GameId As String = "lastoasis" Implements IGamePlugin.GameId
    Public ReadOnly Property DisplayName As String = "Last Oasis" Implements IGamePlugin.DisplayName

    ' ============================================================
    '  Install
    ' ============================================================

    Public Function GetSupportedInstallMethods() As IReadOnlyList(Of InstallMethod) Implements IGamePlugin.GetSupportedInstallMethods
        Return New InstallMethod() {InstallMethod.SteamCmd}
    End Function

    Public Function GetInstallSteps(config As InstallationConfig) As IReadOnlyList(Of InstallStep) Implements IGamePlugin.GetInstallSteps
        Dim steps As New List(Of InstallStep)

        Dim steamStep As New SteamCmdStep()
        steamStep.StepName = "Download Last Oasis Server"
        steamStep.Description = "Download/update via SteamCMD (AppID 920720)"
        steamStep.AppId = 920720
        steamStep.ValidateFiles = True
        steamStep.RequiresLogin = False

        ' Beta branch support
        If config.CustomFields IsNot Nothing Then
            Dim branch = GetField(config.CustomFields, "SteamBranch")
            If Not String.IsNullOrEmpty(branch) Then
                steamStep.BetaBranch = branch
                steamStep.BetaPassword = GetField(config.CustomFields, "SteamBranchPassword")
            End If
        End If

        steps.Add(steamStep)
        Return steps
    End Function

    Public Function GetUpdateSteps(config As InstallationConfig) As IReadOnlyList(Of InstallStep) Implements IGamePlugin.GetUpdateSteps
        ' Update is the same as install for SteamCMD games
        Return GetInstallSteps(config)
    End Function

    ' ============================================================
    '  Instance
    ' ============================================================

    Public Function BuildLaunchArguments(config As InstanceConfig) As String Implements IGamePlugin.BuildLaunchArguments
        Dim args As New List(Of String)

        ' Required backend flags
        args.Add("-log")
        args.Add("-force_steamclient_link")
        args.Add("-messaging")
        args.Add("-NoLiveServer")
        args.Add("-backendapiurloverride=""backend-production.last-oasis.com""")

        ' Realm authentication (installation-level, shared across instances)
        Dim customerKey = GetField(config.CustomFields, "CustomerKey")
        Dim providerKey = GetField(config.CustomFields, "ProviderKey")
        If Not String.IsNullOrEmpty(customerKey) Then
            args.Add($"-CustomerKey={customerKey}")
        End If
        If Not String.IsNullOrEmpty(providerKey) Then
            args.Add($"-ProviderKey={providerKey}")
        End If

        ' Instance identifier — unique per server on this realm
        Dim identifier = GetField(config.CustomFields, "Identifier")
        If String.IsNullOrEmpty(identifier) Then
            identifier = config.InstanceId
        End If
        args.Add($"-identifier={identifier}")

        ' Ports
        Dim port = GetFieldInt(config.CustomFields, "Port", 5555)
        Dim queryPort = GetFieldInt(config.CustomFields, "QueryPort", 27015)
        args.Add($"-port={port}")
        args.Add($"-QueryPort={queryPort}")

        ' RCON
        If Not String.IsNullOrEmpty(config.RconPassword) Then
            Dim rconPort = If(config.RconPort, 8081)
            args.Add($"-RconPort={rconPort}")
            args.Add($"-RconPassword={config.RconPassword}")
        End If

        ' Slots
        Dim slots = GetFieldInt(config.CustomFields, "Slots", 5)
        args.Add($"-slots={slots}")

        ' Connection address override — omit flag entirely when blank
        Dim overrideAddr = GetField(config.CustomFields, "OverrideConnectionAddress")
        If Not String.IsNullOrEmpty(overrideAddr) Then
            args.Add($"-OverrideConnectionAddress={overrideAddr}")
        End If

        ' UE4 headless flags
        args.Add("-nullrhi")
        args.Add("-nosound")
        args.Add("-nographicsadapter")

        Return String.Join(" ", args)
    End Function

    Public Function ValidateConfig(config As InstanceConfig) As IReadOnlyList(Of String) Implements IGamePlugin.ValidateConfig
        Dim errors As New List(Of String)

        If String.IsNullOrEmpty(GetField(config.CustomFields, "CustomerKey")) Then
            errors.Add("CustomerKey is required. Get it from the MyRealm dashboard.")
        End If
        If String.IsNullOrEmpty(GetField(config.CustomFields, "ProviderKey")) Then
            errors.Add("ProviderKey is required. Get it from the MyRealm dashboard.")
        End If
        If String.IsNullOrEmpty(GetField(config.CustomFields, "Identifier")) Then
            errors.Add("Identifier is required. Must be unique per instance on this realm.")
        End If

        Return errors
    End Function

    ' ============================================================
    '  Config schema
    ' ============================================================

    Public Function GetInstallConfigSchema() As IReadOnlyList(Of ConfigFieldDescriptor) Implements IGamePlugin.GetInstallConfigSchema
        Return New ConfigFieldDescriptor() {
            New ConfigFieldDescriptor With {
                .Key = "CustomerKey",
                .Label = "Customer Key",
                .Description = "Realm-wide authentication key from MyRealm dashboard.",
                .FieldType = ConfigFieldType.Password,
                .IsRequired = True,
                .IsSensitive = True
            },
            New ConfigFieldDescriptor With {
                .Key = "ProviderKey",
                .Label = "Provider Key",
                .Description = "Provider authentication key. Revoke to lock out servers using this key.",
                .FieldType = ConfigFieldType.Password,
                .IsRequired = True,
                .IsSensitive = True
            },
            New ConfigFieldDescriptor With {
                .Key = "SteamBranch",
                .Label = "Steam beta branch",
                .Description = "Beta branch name. Leave blank for the default release branch.",
                .FieldType = ConfigFieldType.Text,
                .DefaultValue = ""
            },
            New ConfigFieldDescriptor With {
                .Key = "SteamBranchPassword",
                .Label = "Branch password",
                .Description = "Password for the Steam beta branch, if required.",
                .FieldType = ConfigFieldType.Password,
                .IsSensitive = True
            }
        }
    End Function

    Public Function GetInstanceConfigSchema() As IReadOnlyList(Of ConfigFieldDescriptor) Implements IGamePlugin.GetInstanceConfigSchema
        Return New ConfigFieldDescriptor() {
            New ConfigFieldDescriptor With {
                .Key = "Identifier",
                .Label = "Server Identifier",
                .Description = "Unique identifier for this instance on the realm. Visible in MyRealm dashboard.",
                .FieldType = ConfigFieldType.Text,
                .IsRequired = True
            },
            New ConfigFieldDescriptor With {
                .Key = "Port",
                .Label = "Game Port (UDP)",
                .Description = "Must be unique per instance on this node.",
                .FieldType = ConfigFieldType.IntegerField,
                .DefaultValue = "5555",
                .MinValue = 1024,
                .MaxValue = 65535
            },
            New ConfigFieldDescriptor With {
                .Key = "QueryPort",
                .Label = "Query Port",
                .Description = "Steam query port. Must be unique per instance on this node.",
                .FieldType = ConfigFieldType.IntegerField,
                .DefaultValue = "27015",
                .MinValue = 1024,
                .MaxValue = 65535
            },
            New ConfigFieldDescriptor With {
                .Key = "RconPort",
                .Label = "RCON Port",
                .FieldType = ConfigFieldType.IntegerField,
                .DefaultValue = "8081",
                .MinValue = 1024,
                .MaxValue = 65535
            },
            New ConfigFieldDescriptor With {
                .Key = "RconPassword",
                .Label = "RCON Password",
                .Description = "Leave blank to disable RCON.",
                .FieldType = ConfigFieldType.Password,
                .IsSensitive = True
            },
            New ConfigFieldDescriptor With {
                .Key = "Slots",
                .Label = "Tile Slots",
                .Description = "Number of tile slots. Max 100 per official docs.",
                .FieldType = ConfigFieldType.IntegerField,
                .DefaultValue = "5",
                .MinValue = 1,
                .MaxValue = 100
            },
            New ConfigFieldDescriptor With {
                .Key = "OverrideConnectionAddress",
                .Label = "Override Connection Address",
                .Description = "External IP for player connections. Blank = server auto-detects.",
                .FieldType = ConfigFieldType.Text
            }
        }
    End Function

    ' ============================================================
    '  Crash handling
    ' ============================================================

    Public Function EvaluateCrash(exitCode As Integer,
                                   crashCount As Integer,
                                   policy As CrashRestartPolicy) As RestartDecision Implements IGamePlugin.EvaluateCrash
        ' Exit code 0 = clean shutdown
        If exitCode = 0 Then
            Return RestartDecision.Halt("Clean exit (code 0)")
        End If

        ' Delegate to policy
        Select Case policy
            Case CrashRestartPolicy.NeverRestart
                Return RestartDecision.Halt($"NeverRestart policy (exit code {exitCode})")

            Case CrashRestartPolicy.AlwaysRestart
                Return RestartDecision.Restart(2000, $"AlwaysRestart (exit code {exitCode})")

            Case CrashRestartPolicy.RestartWithBackoff
                Dim delayMs = Math.Min(CInt(Math.Pow(2, crashCount)) * 1000, 300000)
                Return RestartDecision.Restart(delayMs,
                    $"Backoff restart (attempt {crashCount + 1}, delay {delayMs}ms)")

            Case CrashRestartPolicy.RestartLimited
                If crashCount < 5 Then
                    Return RestartDecision.Restart(5000,
                        $"Limited restart (attempt {crashCount + 1}/5)")
                End If
                Return RestartDecision.Halt($"Crash limit reached ({crashCount} crashes)")

            Case Else
                Return RestartDecision.Restart(5000, $"Default restart (exit code {exitCode})")
        End Select
    End Function

    ' ============================================================
    '  Log parsing
    ' ============================================================

    Public Function CreateLogParser() As ILogParser Implements IGamePlugin.CreateLogParser
        Return New LastOasisLogParser()
    End Function

    Public Function GetLogSources(config As InstanceConfig) As IReadOnlyList(Of ILogSource) Implements IGamePlugin.GetLogSources
        ' Last Oasis outputs everything to stdout
        Return New ILogSource() {New StdoutLogSource()}
    End Function

    ' ============================================================
    '  RCON
    ' ============================================================

    Public Function GetRconProtocol() As RconProtocol? Implements IGamePlugin.GetRconProtocol
        Return RconProtocol.SourceRcon
    End Function

    ' ============================================================
    '  Mods — Last Oasis has no server-side mod support
    ' ============================================================

    Public Function CreateModManager() As IModManager Implements IGamePlugin.CreateModManager
        Return Nothing
    End Function

    ' ============================================================
    '  Helpers
    ' ============================================================

    Private Shared Function GetField(fields As Dictionary(Of String, String),
                                      key As String) As String
        If fields Is Nothing Then Return ""
        Dim result As String = Nothing
        If fields.TryGetValue(key, result) Then Return If(result, "")
        Return ""
    End Function

    Private Shared Function GetFieldInt(fields As Dictionary(Of String, String),
                                         key As String,
                                         defaultValue As Integer) As Integer
        Dim strVal = GetField(fields, key)
        Dim parsed As Integer
        If Integer.TryParse(strVal, parsed) Then Return parsed
        Return defaultValue
    End Function

End Class

' ============================================================
'  Last Oasis Log Parser
'  Detects player joins/leaves and UE4 crash patterns
' ============================================================

Public Class LastOasisLogParser
    Implements ILogParser

    Public ReadOnly Property GameId As String = "lastoasis" Implements ILogParser.GameId

    Public Function ParseLine(line As LogLine) As ParsedLogEvent Implements ILogParser.ParseLine
        If line Is Nothing OrElse String.IsNullOrEmpty(line.Text) Then
            Return ParsedLogEvent.NoMatch
        End If

        Dim text = line.Text

        ' Player join detection
        If text.Contains("LogNet: Join succeeded:") Then
            Dim playerName = ExtractAfter(text, "Join succeeded: ")
            Return New ParsedLogEvent With {
                .EventType = LogEventType.PlayerJoin,
                .Message = $"Player joined: {playerName}",
                .PlayerInfo = New PlayerInfo With {
                    .PlayerName = playerName,
                    .JoinedAt = line.Timestamp
                }
            }
        End If

        ' Player leave detection
        If text.Contains("LogNet: UChannel::Close:") OrElse
           text.Contains("LogNet: UNetConnection::Close") Then
            Return New ParsedLogEvent With {
                .EventType = LogEventType.PlayerLeave,
                .Message = "Player disconnected"
            }
        End If

        ' Server ready
        If text.Contains("LogOnline: OSS: Created online async task") OrElse
           text.Contains("LogInit: Display: Engine is initialized") Then
            Return New ParsedLogEvent With {
                .EventType = LogEventType.ServerReady,
                .Message = "Server is ready"
            }
        End If

        ' UE4 crash patterns
        If text.Contains("Fatal error!") OrElse
           text.Contains("Unhandled Exception:") OrElse
           text.Contains("LowLevelFatalError") OrElse
           text.Contains("Access violation") OrElse
           text.Contains("=== Critical error: ===") OrElse
           text.Contains("Assertion failed:") Then
            Return New ParsedLogEvent With {
                .EventType = LogEventType.CrashIndicator,
                .Message = text
            }
        End If

        Return ParsedLogEvent.NoMatch
    End Function

    Public Function GetCrashPatterns() As IReadOnlyList(Of String) Implements ILogParser.GetCrashPatterns
        Return New String() {
            "Fatal error!",
            "Unhandled Exception:",
            "Access violation",
            "LowLevelFatalError",
            "=== Critical error: ===",
            "begin: stack for UAT",
            "Assertion failed:"
        }
    End Function

    Private Shared Function ExtractAfter(text As String, marker As String) As String
        Dim idx = text.IndexOf(marker, StringComparison.Ordinal)
        If idx < 0 Then Return ""
        Return text.Substring(idx + marker.Length).Trim()
    End Function

End Class
