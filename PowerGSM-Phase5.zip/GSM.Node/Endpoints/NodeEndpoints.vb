Imports System
Imports Microsoft.AspNetCore.Builder
Imports Microsoft.AspNetCore.Http
Imports GSM.Node.Api
Imports GSM.Node

' ============================================================
'  System endpoints — version, status, auth
'  Install endpoints — start/cancel/progress, prompt response
' ============================================================

Namespace GSM.Node.Endpoints

    ''' <summary>
    ''' System-level endpoints: version check (unauthenticated),
    ''' node status, authentication.
    ''' </summary>
    Module SystemEndpoints

        Public Sub Map(app As WebApplication)

            ' Version — unauthenticated, used as health check
            app.MapGet("/api/version",
                Function() As IResult
                    Return Results.Ok(New With {
                        .application = "PowerGSM.Node",
                        .version = GetType(ProcessManager).Assembly.
                            GetName().Version?.ToString(),
                        .runtime = System.Runtime.InteropServices.
                            RuntimeInformation.FrameworkDescription
                    })
                End Function)

            ' Node status — authenticated
            app.MapGet("/api/status",
                Function(pm As ProcessManager,
                         config As NodeConfiguration) As IResult
                    Return Results.Ok(pm.GetNodeStatus(config))
                End Function)

            ' Auth handshake — manager calls this to establish session
            app.MapPost("/api/auth",
                Function(request As NodeAuthRequest,
                         config As NodeConfiguration) As IResult

                    If String.Equals(request.SharedSecret, config.AuthToken,
                                     StringComparison.Ordinal) Then
                        Return Results.Ok(New NodeAuthResponse With {
                            .Accepted = True,
                            .SessionToken = Guid.NewGuid().ToString("N"),
                            .Reason = "Authenticated"
                        })
                    End If

                    Return Results.Ok(New NodeAuthResponse With {
                        .Accepted = False,
                        .Reason = "Invalid shared secret"
                    })
                End Function)

        End Sub

    End Module

    ''' <summary>
    ''' Installation endpoints: start install/update, check progress,
    ''' cancel, respond to interactive prompts.
    ''' </summary>
    Module InstallEndpoints

        Public Sub Map(app As WebApplication)

            ' Start an install/update operation
            app.MapPost("/api/install",
                Function(request As InstallRequest,
                         runner As InstallRunner) As IResult
                    Dim progress = runner.StartInstall(request)
                    If progress.OperationState = InstallationOperationState.Failed Then
                        Return Results.Conflict(progress)
                    End If
                    Return Results.Accepted(Nothing, progress)
                End Function)

            ' Get install progress
            app.MapGet("/api/install/{installationId}/progress",
                Function(installationId As String,
                         runner As InstallRunner) As IResult
                    Return Results.Ok(runner.GetProgress(installationId))
                End Function)

            ' Cancel an install
            app.MapPost("/api/install/{installationId}/cancel",
                Function(installationId As String,
                         runner As InstallRunner) As IResult
                    Dim cancelled = runner.CancelInstall(installationId)
                    If cancelled Then
                        Return Results.Ok(New With {.cancelled = True})
                    End If
                    Return Results.NotFound(New With {
                        .error = "No active operation for this installation"
                    })
                End Function)

            ' Respond to interactive prompt (Steam Guard, 2FA)
            app.MapPost("/api/install/{installationId}/prompt",
                Function(installationId As String,
                         response As PromptResponse,
                         runner As InstallRunner) As IResult
                    response.OperationId = installationId
                    Dim ok = runner.ProvideInput(installationId, response.Value)
                    If ok Then
                        Return Results.Ok(New With {.accepted = True})
                    End If
                    Return Results.NotFound(New With {
                        .error = "No pending prompt for this installation"
                    })
                End Function)

        End Sub

    End Module

End Namespace
