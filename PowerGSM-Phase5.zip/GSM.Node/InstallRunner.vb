Imports System
Imports System.Collections.Concurrent
Imports System.Diagnostics
Imports System.IO
Imports System.IO.Compression
Imports System.Net.Http
Imports System.Threading
Imports System.Threading.Tasks
Imports GSM.Plugin
Imports GSM.Node.Api
Imports Microsoft.Extensions.Logging

' ============================================================
'  InstallRunner — executes installation/update operations
'
'  Receives a list of InstallStep from the manager (resolved by
'  the plugin on the manager side) and executes them sequentially.
'
'  Supported step types:
'    SteamCmdStep     — run SteamCMD with app ID, branch, creds
'    DownloadFileStep — HTTP download, optional archive extraction
'    CopyFileStep     — copy/move files within install dir
'    WriteFileStep    — write text content to a file
'    RunProcessStep   — run an arbitrary process with timeout
'
'  Long-running operations report progress. The manager polls
'  for status via GET /api/install/{id}/progress.
' ============================================================

Namespace GSM.Node

    Public Class InstallRunner

        Private ReadOnly _operations As New ConcurrentDictionary(Of String, ActiveOperation)
        Private ReadOnly _database As NodeDatabase
        Private ReadOnly _config As NodeConfiguration
        Private ReadOnly _logger As Microsoft.Extensions.Logging.ILogger(Of InstallRunner)
        Private ReadOnly _httpClient As New HttpClient()
        Private _runningCount As Integer = 0

        Public Sub New(database As NodeDatabase,
                       config As NodeConfiguration,
                       logger As Microsoft.Extensions.Logging.ILogger(Of InstallRunner))
            _database = database
            _config = config
            _logger = logger
        End Sub

        ''' <summary>
        ''' Starts an install/update operation. Returns immediately
        ''' with the initial progress state.
        ''' </summary>
        Public Function StartInstall(request As InstallRequest) As InstallProgressResponse

            If _runningCount >= _config.MaxConcurrentInstalls Then
                Return New InstallProgressResponse With {
                    .InstallationId = request.InstallationId,
                    .OperationState = InstallationOperationState.Failed,
                    .ErrorMessage = $"Max concurrent installs ({_config.MaxConcurrentInstalls}) reached"
                }
            End If

            Dim op As New ActiveOperation()
            op.InstallationId = request.InstallationId
            op.GameId = request.GameId
            op.InstallPath = request.InstallPath
            op.Steps = If(request.Steps, New List(Of InstallStep))
            op.SteamCredentials = request.SteamCredentials
            op.State = InstallationOperationState.Queued
            op.StartedAt = DateTime.UtcNow
            op.TotalSteps = op.Steps.Count
            op.CancellationSource = New CancellationTokenSource()

            _operations(request.InstallationId) = op

            ' Run in background
            Task.Run(Function() ExecuteOperationAsync(op))

            Return BuildProgress(op)
        End Function

        ''' <summary>
        ''' Returns the current progress of an operation.
        ''' </summary>
        Public Function GetProgress(installationId As String) As InstallProgressResponse
            Dim op As ActiveOperation = Nothing
            If Not _operations.TryGetValue(installationId, op) Then
                Return New InstallProgressResponse With {
                    .InstallationId = installationId,
                    .OperationState = InstallationOperationState.Failed,
                    .ErrorMessage = "No operation found for this installation"
                }
            End If
            Return BuildProgress(op)
        End Function

        ''' <summary>
        ''' Cancels a running operation.
        ''' </summary>
        Public Function CancelInstall(installationId As String) As Boolean
            Dim op As ActiveOperation = Nothing
            If Not _operations.TryGetValue(installationId, op) Then
                Return False
            End If
            op.CancellationSource.Cancel()
            op.State = InstallationOperationState.Cancelled
            Return True
        End Function

        ''' <summary>
        ''' Provides input to a waiting operation (e.g. Steam Guard code).
        ''' </summary>
        Public Function ProvideInput(installationId As String, value As String) As Boolean
            Dim op As ActiveOperation = Nothing
            If Not _operations.TryGetValue(installationId, op) Then
                Return False
            End If
            If op.PendingInputTcs IsNot Nothing Then
                op.PendingInputTcs.TrySetResult(value)
                Return True
            End If
            Return False
        End Function

        ' ============================================================
        '  Step execution
        ' ============================================================

        Private Async Function ExecuteOperationAsync(op As ActiveOperation) As Task
            Interlocked.Increment(_runningCount)
            Try
                Directory.CreateDirectory(op.InstallPath)
                op.State = InstallationOperationState.Downloading

                For i = 0 To op.Steps.Count - 1
                    If op.CancellationSource.IsCancellationRequested Then
                        op.State = InstallationOperationState.Cancelled
                        Return
                    End If

                    op.CurrentStepIndex = i
                    op.CurrentStepName = If(op.Steps(i).StepName, $"Step {i + 1}")
                    op.ProgressPercent = CDbl(i) / CDbl(op.TotalSteps) * 100.0

                    _logger.LogInformation("Install {Id}: step {Step}/{Total} - {Name}",
                                           op.InstallationId, i + 1, op.TotalSteps, op.CurrentStepName)

                    Await ExecuteStepAsync(op, op.Steps(i))
                Next

                op.State = InstallationOperationState.Completed
                op.ProgressPercent = 100
                op.CompletedAt = DateTime.UtcNow

                _database.RecordInstallHistory(op.InstallationId, op.GameId,
                                               op.StartedAt, op.CompletedAt.Value,
                                               True, op.TotalSteps, Nothing)

                _logger.LogInformation("Install {Id}: completed successfully", op.InstallationId)

            Catch ex As OperationCanceledException
                op.State = InstallationOperationState.Cancelled
                _logger.LogInformation("Install {Id}: cancelled", op.InstallationId)

            Catch ex As Exception
                op.State = InstallationOperationState.Failed
                op.ErrorMessage = ex.Message
                op.CompletedAt = DateTime.UtcNow

                _database.RecordInstallHistory(op.InstallationId, op.GameId,
                                               op.StartedAt, op.CompletedAt.Value,
                                               False, op.TotalSteps, ex.Message)

                _logger.LogError(ex, "Install {Id}: failed", op.InstallationId)
            Finally
                Interlocked.Decrement(_runningCount)
            End Try
        End Function

        Private Async Function ExecuteStepAsync(op As ActiveOperation,
                                                 currentStep As InstallStep) As Task
            Dim token = op.CancellationSource.Token

            If TypeOf currentStep Is SteamCmdStep Then
                Await ExecuteSteamCmdStepAsync(op, DirectCast(currentStep, SteamCmdStep), token)

            ElseIf TypeOf currentStep Is DownloadFileStep Then
                Await ExecuteDownloadStepAsync(op, DirectCast(currentStep, DownloadFileStep), token)

            ElseIf TypeOf currentStep Is CopyFileStep Then
                ExecuteCopyStep(op, DirectCast(currentStep, CopyFileStep))

            ElseIf TypeOf currentStep Is WriteFileStep Then
                ExecuteWriteFileStep(op, DirectCast(currentStep, WriteFileStep))

            ElseIf TypeOf currentStep Is RunProcessStep Then
                Await ExecuteRunProcessStepAsync(op, DirectCast(currentStep, RunProcessStep), token)

            Else
                Throw New NotSupportedException($"Unknown install step type: {currentStep.GetType().Name}")
            End If
        End Function

        Private Async Function ExecuteSteamCmdStepAsync(op As ActiveOperation,
                                                         steamStep As SteamCmdStep,
                                                         cancellation As CancellationToken) As Task
            op.State = InstallationOperationState.Downloading

            ' Find SteamCMD
            Dim steamCmdPath = FindSteamCmd()
            If steamCmdPath Is Nothing Then
                Throw New FileNotFoundException(
                    "SteamCMD not found. Install it and ensure it's in PATH or in the data directory.")
            End If

            ' Build arguments
            Dim args = $"+force_install_dir ""{op.InstallPath}"" "

            ' Login
            If steamStep.RequiresLogin AndAlso op.SteamCredentials IsNot Nothing AndAlso
               Not op.SteamCredentials.IsAnonymous Then
                args &= $"+login {op.SteamCredentials.Username} {op.SteamCredentials.Password} "
            Else
                args &= "+login anonymous "
            End If

            ' App update
            args &= $"+app_update {steamStep.AppId} "
            If Not String.IsNullOrEmpty(steamStep.BetaBranch) Then
                args &= $"-beta {steamStep.BetaBranch} "
                If Not String.IsNullOrEmpty(steamStep.BetaPassword) Then
                    args &= $"-betapassword {steamStep.BetaPassword} "
                End If
            End If
            If steamStep.ValidateFiles Then
                args &= "validate "
            End If
            args &= "+quit"

            ' Run SteamCMD
            Dim psi As New ProcessStartInfo()
            psi.FileName = steamCmdPath
            psi.Arguments = args
            psi.UseShellExecute = False
            psi.RedirectStandardOutput = True
            psi.RedirectStandardError = True
            psi.RedirectStandardInput = True
            psi.CreateNoWindow = True

            Using proc As New Process()
                proc.StartInfo = psi
                proc.Start()

                ' Read output for progress tracking
                Dim outputTask = ReadSteamCmdOutputAsync(proc, op, cancellation)

                Await proc.WaitForExitAsync(cancellation)
                Await outputTask

                If proc.ExitCode <> 0 Then
                    Throw New Exception($"SteamCMD exited with code {proc.ExitCode}")
                End If
            End Using
        End Function

        Private Async Function ExecuteDownloadStepAsync(op As ActiveOperation,
                                                         dlStep As DownloadFileStep,
                                                         cancellation As CancellationToken) As Task
            op.State = InstallationOperationState.Downloading
            Dim destPath = Path.Combine(op.InstallPath, dlStep.DestinationRelativePath)
            Directory.CreateDirectory(Path.GetDirectoryName(destPath))

            Using response = Await _httpClient.GetAsync(dlStep.Url,
                    HttpCompletionOption.ResponseHeadersRead, cancellation)
                response.EnsureSuccessStatusCode()
                Using fileStream As New FileStream(destPath, FileMode.Create,
                                                    FileAccess.Write, FileShare.None)
                    Await response.Content.CopyToAsync(fileStream, cancellation)
                End Using
            End Using

            If dlStep.ExtractArchive Then
                op.State = InstallationOperationState.Extracting
                IO.Compression.ZipFile.ExtractToDirectory(destPath, op.InstallPath, True)
                File.Delete(destPath)
            End If
        End Function

        Private Sub ExecuteCopyStep(op As ActiveOperation, cpStep As CopyFileStep)
            op.State = InstallationOperationState.Configuring
            Dim srcPath = Path.Combine(op.InstallPath, cpStep.SourceRelativePath)
            Dim dstPath = Path.Combine(op.InstallPath, cpStep.DestinationRelativePath)
            Directory.CreateDirectory(Path.GetDirectoryName(dstPath))
            File.Copy(srcPath, dstPath, cpStep.Overwrite)
        End Sub

        Private Sub ExecuteWriteFileStep(op As ActiveOperation, wfStep As WriteFileStep)
            op.State = InstallationOperationState.Configuring
            Dim filePath = Path.Combine(op.InstallPath, wfStep.RelativePath)
            If File.Exists(filePath) AndAlso Not wfStep.OverwriteExisting Then
                Return
            End If
            Directory.CreateDirectory(Path.GetDirectoryName(filePath))
            File.WriteAllText(filePath, wfStep.Content)
        End Sub

        Private Async Function ExecuteRunProcessStepAsync(op As ActiveOperation,
                                                           rpStep As RunProcessStep,
                                                           cancellation As CancellationToken) As Task
            op.State = InstallationOperationState.Configuring
            Dim psi As New ProcessStartInfo()
            psi.FileName = rpStep.ExecutablePath
            psi.Arguments = If(rpStep.Arguments, "")
            psi.WorkingDirectory = If(rpStep.WorkingDirectory, op.InstallPath)
            psi.UseShellExecute = False
            psi.RedirectStandardOutput = True
            psi.CreateNoWindow = True

            Using proc As New Process()
                proc.StartInfo = psi
                proc.Start()

                Using cts = CancellationTokenSource.CreateLinkedTokenSource(cancellation)
                    cts.CancelAfter(rpStep.TimeoutMs)
                    Try
                        Await proc.WaitForExitAsync(cts.Token)
                    Catch ex As OperationCanceledException
                        Try
                            proc.Kill(entireProcessTree:=True)
                        Catch
                            proc.Kill()
                        End Try
                        Throw New TimeoutException(
                            $"Process step '{rpStep.StepName}' timed out after {rpStep.TimeoutMs}ms")
                    End Try
                End Using

                If proc.ExitCode <> rpStep.ExpectedExitCode Then
                    Throw New Exception(
                        $"Process step '{rpStep.StepName}' exited with code {proc.ExitCode} (expected {rpStep.ExpectedExitCode})")
                End If
            End Using
        End Function

        Private Async Function ReadSteamCmdOutputAsync(proc As Process,
                                                        op As ActiveOperation,
                                                        cancellation As CancellationToken) As Task
            While Not proc.StandardOutput.EndOfStream
                Dim line = Await proc.StandardOutput.ReadLineAsync(cancellation)
                If line IsNot Nothing Then
                    op.Message = line
                    If line.Contains("progress:") OrElse
                       line.Contains("Update state") Then
                        _logger.LogDebug("SteamCMD: {Line}", line)
                    End If
                End If
            End While
        End Function

        ' ============================================================
        '  Helpers
        ' ============================================================

        Private Function FindSteamCmd() As String
            ' Check common locations
            Dim candidates = New String() {
                Path.Combine(_config.DataDirectory, "steamcmd", "steamcmd.exe"),
                Path.Combine(_config.DataDirectory, "steamcmd", "steamcmd.sh"),
                "steamcmd",
                "steamcmd.exe",
                "/usr/games/steamcmd"
            }

            For Each candidate In candidates
                Try
                    If File.Exists(candidate) Then Return candidate
                Catch
                End Try
            Next

            ' Try PATH
            Try
                Dim psi As New ProcessStartInfo("which", "steamcmd")
                psi.UseShellExecute = False
                psi.RedirectStandardOutput = True
                psi.CreateNoWindow = True
                Using proc = Process.Start(psi)
                    Dim result = proc.StandardOutput.ReadToEnd().Trim()
                    proc.WaitForExit()
                    If proc.ExitCode = 0 AndAlso Not String.IsNullOrEmpty(result) Then
                        Return result
                    End If
                End Using
            Catch
            End Try

            Return Nothing
        End Function

        Private Shared Function BuildProgress(op As ActiveOperation) As InstallProgressResponse
            Return New InstallProgressResponse With {
                .InstallationId = op.InstallationId,
                .OperationState = op.State,
                .CurrentStepIndex = op.CurrentStepIndex,
                .TotalSteps = op.TotalSteps,
                .CurrentStepName = op.CurrentStepName,
                .ProgressPercent = op.ProgressPercent,
                .Message = op.Message,
                .ErrorMessage = op.ErrorMessage
            }
        End Function

    End Class

    ' ============================================================
    '  ActiveOperation — tracks a running install/update
    ' ============================================================

    Friend Class ActiveOperation
        Public Property InstallationId As String
        Public Property GameId As String
        Public Property InstallPath As String
        Public Property Steps As List(Of InstallStep)
        Public Property SteamCredentials As SteamCredential
        Public Property State As InstallationOperationState
        Public Property StartedAt As DateTime
        Public Property CompletedAt As DateTime?
        Public Property CurrentStepIndex As Integer
        Public Property TotalSteps As Integer
        Public Property CurrentStepName As String
        Public Property ProgressPercent As Double
        Public Property Message As String
        Public Property ErrorMessage As String
        Public Property CancellationSource As CancellationTokenSource
        Public Property PendingInputTcs As TaskCompletionSource(Of String)
    End Class

End Namespace
