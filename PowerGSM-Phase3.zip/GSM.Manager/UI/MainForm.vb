Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports Microsoft.Extensions.DependencyInjection
Imports GSM.Manager
Imports GSM.Manager.Data

' ============================================================
'  MainForm — primary application window
'
'  Layout:
'    Left:  TreeView (nodes → installations → instances)
'    Right: Panel that swaps content based on tree selection
'
'  Tree structure:
'    [Nodes]
'      ├─ NodeName (host:port)
'      │   ├─ [Installations]
'      │   │   ├─ InstallName (gameId)
'      │   │   │   ├─ InstanceName (state)
'      │   │   │   └─ InstanceName (state)
'      │   │   └─ InstallName (gameId)
'      │   └─ ...
'      └─ NodeName
'    [Automation Rules]
'    [Settings]
' ============================================================

Namespace GSM.Manager.UI

    Public Class MainForm
        Inherits Form

        ' ---- Controls ----
        Private WithEvents _splitContainer As SplitContainer
        Private WithEvents _treeView As TreeView
        Private _contentPanel As Panel
        Private _menuStrip As MenuStrip
        Private _statusStrip As StatusStrip
        Private _statusLabel As ToolStripStatusLabel

        ' ---- Tree root nodes ----
        Private _nodesRoot As TreeNode
        Private _automationRoot As TreeNode
        Private _settingsRoot As TreeNode

        ' ---- Current panel ----
        Private _currentPanel As UserControl

        Public Sub New()
            InitializeComponent()
            BuildTree()
            ShowPanel(New WelcomePanel())
        End Sub

        Private Sub InitializeComponent()
            Me.Text = "PowerGSM — Game Server Manager"
            Me.Size = New Size(1200, 800)
            Me.StartPosition = FormStartPosition.CenterScreen
            Me.MinimumSize = New Size(800, 600)

            ' ---- Menu ----
            _menuStrip = New MenuStrip()

            Dim fileMenu As New ToolStripMenuItem("&File")
            Dim exitItem As New ToolStripMenuItem("E&xit", Nothing,
                Sub(s, e) Me.Close())
            exitItem.ShortcutKeys = Keys.Alt Or Keys.F4
            fileMenu.DropDownItems.Add(exitItem)

            Dim nodesMenu As New ToolStripMenuItem("&Nodes")
            Dim addNodeItem As New ToolStripMenuItem("&Add Node...", Nothing,
                Sub(s, e) OnAddNode())
            nodesMenu.DropDownItems.Add(addNodeItem)

            Dim toolsMenu As New ToolStripMenuItem("&Tools")
            Dim reloadPluginsItem As New ToolStripMenuItem("&Reload Plugins", Nothing,
                Sub(s, e) OnReloadPlugins())
            toolsMenu.DropDownItems.Add(reloadPluginsItem)

            _menuStrip.Items.AddRange(New ToolStripItem() {fileMenu, nodesMenu, toolsMenu})
            Me.MainMenuStrip = _menuStrip

            ' ---- Status bar ----
            _statusStrip = New StatusStrip()
            _statusLabel = New ToolStripStatusLabel("Ready")
            _statusLabel.Spring = True
            _statusLabel.TextAlign = ContentAlignment.MiddleLeft
            _statusStrip.Items.Add(_statusLabel)

            ' ---- Split container ----
            _splitContainer = New SplitContainer()
            _splitContainer.Dock = DockStyle.Fill
            _splitContainer.SplitterDistance = 280
            _splitContainer.FixedPanel = FixedPanel.Panel1

            ' ---- Tree view ----
            _treeView = New TreeView()
            _treeView.Dock = DockStyle.Fill
            _treeView.HideSelection = False
            _treeView.ShowLines = True
            _treeView.ShowPlusMinus = True
            _treeView.ShowRootLines = True
            _treeView.Font = New Font("Segoe UI", 9.5F)
            _splitContainer.Panel1.Controls.Add(_treeView)

            ' ---- Content panel ----
            _contentPanel = New Panel()
            _contentPanel.Dock = DockStyle.Fill
            _contentPanel.Padding = New Padding(8)
            _splitContainer.Panel2.Controls.Add(_contentPanel)

            ' ---- Assembly ----
            Me.Controls.Add(_splitContainer)
            Me.Controls.Add(_statusStrip)
            Me.Controls.Add(_menuStrip)
        End Sub

        ' ============================================================
        '  Tree building
        ' ============================================================

        Private Sub BuildTree()
            _treeView.Nodes.Clear()

            _nodesRoot = New TreeNode("Nodes")
            _nodesRoot.Tag = "root:nodes"

            _automationRoot = New TreeNode("Automation Rules")
            _automationRoot.Tag = "root:automation"

            _settingsRoot = New TreeNode("Settings")
            _settingsRoot.Tag = "root:settings"

            _treeView.Nodes.AddRange(New TreeNode() {
                _nodesRoot, _automationRoot, _settingsRoot
            })

            ' Populate from database
            RefreshNodeTree()

            _nodesRoot.Expand()
        End Sub

        ''' <summary>
        ''' Reloads the tree from the database. Safe to call after
        ''' adding/removing nodes, installations, or instances.
        ''' </summary>
        Public Sub RefreshNodeTree()
            _nodesRoot.Nodes.Clear()

            Using scope = ManagerProgram.Services.CreateScope()
                Dim db = scope.ServiceProvider.GetRequiredService(Of GsmDbContext)()

                Dim nodes = db.Nodes.ToList()
                For Each nodeEntity In nodes
                    Dim nodeTreeNode As New TreeNode($"{nodeEntity.DisplayName} ({nodeEntity.HostAddress}:{nodeEntity.Port})")
                    nodeTreeNode.Tag = $"node:{nodeEntity.NodeId}"

                    ' Load installations for this node
                    Dim installations = db.Installations.
                        Where(Function(i) i.NodeId = nodeEntity.NodeId).
                        ToList()

                    For Each installEntity In installations
                        Dim installTreeNode As New TreeNode($"{installEntity.DisplayName} ({installEntity.GameId})")
                        installTreeNode.Tag = $"installation:{installEntity.InstallationId}"

                        ' Load instances for this installation
                        Dim instances = db.Instances.
                            Where(Function(i) i.InstallationId = installEntity.InstallationId).
                            ToList()

                        For Each instanceEntity In instances
                            Dim instanceTreeNode As New TreeNode(instanceEntity.DisplayName)
                            instanceTreeNode.Tag = $"instance:{instanceEntity.InstanceId}"
                            installTreeNode.Nodes.Add(instanceTreeNode)
                        Next

                        nodeTreeNode.Nodes.Add(installTreeNode)
                    Next

                    _nodesRoot.Nodes.Add(nodeTreeNode)
                Next
            End Using
        End Sub

        ' ============================================================
        '  Tree selection
        ' ============================================================

        Private Sub TreeView_AfterSelect(sender As Object, e As TreeViewEventArgs) Handles _treeView.AfterSelect
            If e.Node Is Nothing OrElse e.Node.Tag Is Nothing Then Return

            Dim tag = e.Node.Tag.ToString()
            Dim parts = tag.Split(":"c, 2)
            If parts.Length < 2 Then Return

            Dim kind = parts(0)
            Dim entityId = parts(1)

            Select Case kind
                Case "root"
                    Select Case entityId
                        Case "nodes"
                            ShowPanel(New WelcomePanel())
                        Case "automation"
                            SetStatus("Automation rules — coming in Phase 5")
                        Case "settings"
                            SetStatus("Settings — coming in Phase 5")
                    End Select

                Case "node"
                    ShowPanel(New NodePanel(entityId))

                Case "installation"
                    SetStatus($"Installation selected: {entityId}")
                    ' InstallationPanel comes in Phase 5

                Case "instance"
                    ShowPanel(New InstancePanel(entityId))

            End Select
        End Sub

        ' ============================================================
        '  Panel management
        ' ============================================================

        Private Sub ShowPanel(panel As UserControl)
            If _currentPanel IsNot Nothing Then
                _contentPanel.Controls.Remove(_currentPanel)
                _currentPanel.Dispose()
            End If
            _currentPanel = panel
            panel.Dock = DockStyle.Fill
            _contentPanel.Controls.Add(panel)
        End Sub

        Public Sub SetStatus(text As String)
            _statusLabel.Text = text
        End Sub

        ' ============================================================
        '  Menu handlers (stubs for Phase 3)
        ' ============================================================

        Private Sub OnAddNode()
            ' NodeSetupForm comes in Phase 5
            MessageBox.Show("Add Node form will be available in Phase 5.",
                          "Not Yet Implemented",
                          MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Sub

        Private Sub OnReloadPlugins()
            ' PluginRegistry comes in Phase 4
            MessageBox.Show("Plugin reload will be available in Phase 4.",
                          "Not Yet Implemented",
                          MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Sub

    End Class

End Namespace
